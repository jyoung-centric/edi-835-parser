<#
.SYNOPSIS  Self-test suite for the UiPath Dev Accelerator (Windows).
.DESCRIPTION
    Windows/PowerShell parity of run_tests.sh. Requires Python 3 on PATH.
    No UiPath install, no network, no Orchestrator creds required.
#>
$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$fix  = Join-Path $root 'tests\fixtures'
$tmp  = Join-Path $env:TEMP ("udatest_" + [System.Guid]::NewGuid().ToString('N').Substring(0,8))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null

$py = (Get-Command python -ErrorAction SilentlyContinue) ?? (Get-Command py -ErrorAction SilentlyContinue)
if (-not $py) { Write-Error "Python 3 not found on PATH"; exit 2 }
$python = $py.Source

$script:pass = 0; $script:fail = 0
function Check($name, $want, $got) {
    if ($got -eq $want) { Write-Host "  PASS  $name"; $script:pass++ }
    else { Write-Host "  FAIL  $name (exit $got, wanted $want)"; $script:fail++ }
}
function Py { & $python @args 2>&1 | Out-Null; return $LASTEXITCODE }

Write-Host "== uipath-author =="
Check "generate (with sd: prefix)" 0 (Py "$root\skills\uipath-author\scripts\new_workflow.py" `
    --name T_Basic --arg "in_s:In:x:String" --arg "io_dt:InOut:sd:DataTable" --out "$tmp\T_Basic.xaml")
Check "validate generated" 0 (Py "$root\skills\uipath-author\scripts\validate_xaml.py" "$tmp\T_Basic.xaml")
Check "sd: auto-declared" 0 ([int](-not (Select-String -Path "$tmp\T_Basic.xaml" -Pattern 'xmlns:sd=' -Quiet)))
Set-Content "$tmp\bad.xaml" '<Activity><znk:X/></Activity>'
$r = Py "$root\skills\uipath-author\scripts\validate_xaml.py" "$tmp\bad.xaml"
Check "validator rejects broken xaml" 0 ([int]($r -eq 0))

Write-Host "== uipath-reader =="
$o = & $python "$root\skills\uipath-reader\scripts\read_workflow.py" "$fix\AddOutputNotes.xaml"
Check "outline names workflow" 0 ([int](-not ($o -match 'WORKFLOW: AddOutputNotes')))

Write-Host "== uipath-selectors =="
Check "extract (json) on fixtures" 0 (Py "$root\skills\uipath-selectors\scripts\extract_selectors.py" $fix --json)

Write-Host "== uipath-plan (+ hand-off) =="
Check "verify_grounding (offline)" 0 (Py "$root\skills\uipath-plan\scripts\verify_grounding.py" --index "$fix\hc360_index.json")
New-Item -ItemType Directory -Force -Path "$tmp\proj\DataFiles" | Out-Null
Copy-Item "$fix\project.json" "$tmp\proj\project.json"
Check "build_from_manifest end-to-end" 0 (Py "$root\skills\uipath-plan\scripts\build_from_manifest.py" `
    "$root\skills\uipath-plan\examples\EXAMPLE_manifest.json" --project "$tmp\proj")

Write-Host "== uipath-init =="
Check "init generates CLAUDE.md" 0 (Py "$root\skills\uipath-init\scripts\init_claude_md.py" `
    "$tmp\proj" --out "$tmp\CLAUDE.md" --force)

Write-Host "== uipath-orchestrator-api =="
Check "extract_endpoints regenerates refs" 0 (Py "$root\skills\uipath-orchestrator-api\scripts\extract_endpoints.py" `
    "$root\skills\uipath-orchestrator-api\swagger.json" "$tmp\refs")

Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
Write-Host ""
Write-Host "==================================================="
Write-Host "  RESULT: $script:pass passed, $script:fail failed"
Write-Host "==================================================="
if ($script:fail -gt 0) { exit 1 } else { exit 0 }
