#!/usr/bin/env bash
# Self-test suite for the UiPath Dev Accelerator. Exercises every skill's scripts
# against the bundled fixtures. No UiPath install, no network, no creds required.
# Windows: run tests/run_tests.ps1 instead.
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FIX="$ROOT/tests/fixtures"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
PASS=0; FAIL=0
py() { python3 "$@"; }
check() { # name, expected-exit, actual-exit
  if [[ "$2" == "$3" ]]; then echo "  PASS  $1"; PASS=$((PASS+1));
  else echo "  FAIL  $1 (exit $3, wanted $2)"; FAIL=$((FAIL+1)); fi
}

echo "== uipath-author =="
py "$ROOT/skills/uipath-author/scripts/new_workflow.py" --name T_Basic \
   --arg "in_s:In:x:String" --arg "io_dt:InOut:sd:DataTable" \
   --out "$TMP/T_Basic.xaml" >/dev/null 2>&1; check "generate (with sd: prefix)" 0 $?
py "$ROOT/skills/uipath-author/scripts/validate_xaml.py" "$TMP/T_Basic.xaml" >/dev/null 2>&1
check "validate generated" 0 $?
grep -q 'xmlns:sd=' "$TMP/T_Basic.xaml"; check "sd: auto-declared" 0 $?
# validator must REJECT a broken file
printf '<Activity><znk:X/></Activity>' > "$TMP/bad.xaml"
py "$ROOT/skills/uipath-author/scripts/validate_xaml.py" "$TMP/bad.xaml" >/dev/null 2>&1
[[ $? -ne 0 ]]; check "validator rejects broken xaml" 0 $?

echo "== uipath-reader =="
py "$ROOT/skills/uipath-reader/scripts/read_workflow.py" "$FIX/AddOutputNotes.xaml" \
   | grep -q "WORKFLOW: AddOutputNotes"; check "outline names workflow" 0 $?
py "$ROOT/skills/uipath-reader/scripts/read_workflow.py" "$FIX/AddOutputNotes.xaml" --summary \
   | grep -q "activities"; check "summary mode" 0 $?

echo "== uipath-selectors =="
py "$ROOT/skills/uipath-selectors/scripts/extract_selectors.py" "$FIX" --json \
   >/dev/null 2>&1; check "extract (json) on fixtures" 0 $?

echo "== uipath-plan =="
py "$ROOT/skills/uipath-plan/scripts/project_index.py" "$FIX/.." >/dev/null 2>&1
check "project_index runs" 0 $?
py "$ROOT/skills/uipath-plan/scripts/verify_grounding.py" \
   --index "$FIX/hc360_index.json" >/dev/null 2>&1; check "verify_grounding (offline)" 0 $?

echo "== uipath-plan → uipath-author hand-off =="
mkdir -p "$TMP/proj/DataFiles"
cp "$ROOT/tests/fixtures/project.json" "$TMP/proj/project.json" 2>/dev/null || \
  cp /home/jeremy-young/centric/pgh_postpay_dispatcher/project.json "$TMP/proj/project.json" 2>/dev/null || \
  echo '{"name":"Test","dependencies":{}}' > "$TMP/proj/project.json"
py "$ROOT/skills/uipath-plan/scripts/build_from_manifest.py" \
   "$ROOT/skills/uipath-plan/examples/EXAMPLE_manifest.json" --project "$TMP/proj" \
   >/dev/null 2>&1; check "build_from_manifest end-to-end" 0 $?
py "$ROOT/skills/uipath-reader/scripts/read_workflow.py" \
   "$TMP/proj/DataFiles/ProcessContractWorklist.xaml" | grep -q "INVOKES:"
check "generated scaffold has wired invokes" 0 $?

echo "== uipath-init =="
py "$ROOT/skills/uipath-init/scripts/init_claude_md.py" "$TMP/proj" \
   --out "$TMP/CLAUDE.md" --force >/dev/null 2>&1; check "init generates CLAUDE.md" 0 $?
grep -q "UiPath Dev Accelerator" "$TMP/CLAUDE.md" 2>/dev/null
check "CLAUDE.md references the accelerator" 0 $?

echo "== uipath-orchestrator-api =="
py "$ROOT/skills/uipath-orchestrator-api/scripts/extract_endpoints.py" \
   "$ROOT/skills/uipath-orchestrator-api/swagger.json" "$TMP/refs" >/dev/null 2>&1
check "extract_endpoints regenerates refs" 0 $?
py -c "import ast,sys; ast.parse(open('$ROOT/skills/uipath-orchestrator-api/scripts/orch_call.py').read())"
check "orch_call parses" 0 $?

echo
echo "==================================================="
echo "  RESULT: $PASS passed, $FAIL failed"
echo "==================================================="
[[ $FAIL -eq 0 ]]
