#!/usr/bin/env bash
# Install the UiPath Dev Accelerator skills for Claude Code (Linux/macOS).
# Windows users: use install.ps1 instead.
#
# Usage:
#   ./install.sh                       # user scope (~/.claude/skills) — all projects
#   ./install.sh --scope project [DIR] # project scope (<DIR>/.claude/skills)
#   ./install.sh --force               # overwrite existing installed copies
set -euo pipefail

SCOPE="user"
PROJECT_DIR="$(pwd)"
FORCE=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --scope) SCOPE="$2"; shift 2 ;;
    --force) FORCE=1; shift ;;
    *) PROJECT_DIR="$1"; shift ;;
  esac
done

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILLS_SRC="$REPO_ROOT/skills"
[[ -d "$SKILLS_SRC" ]] || { echo "skills/ not found at $SKILLS_SRC"; exit 1; }

if [[ "$SCOPE" == "user" ]]; then
  DEST="$HOME/.claude/skills"
else
  DEST="$PROJECT_DIR/.claude/skills"
fi
mkdir -p "$DEST"

echo "UiPath Dev Accelerator — installing skills"
echo "  scope : $SCOPE"
echo "  dest  : $DEST"
command -v python3 >/dev/null 2>&1 && echo "  python: $(command -v python3)" \
  || echo "  WARNING: python3 not on PATH — the skills' scripts need Python 3."
echo

count=0
for d in "$SKILLS_SRC"/*/; do
  name="$(basename "$d")"
  target="$DEST/$name"
  if [[ -e "$target" && $FORCE -eq 0 ]]; then
    echo "skip  $name  (exists — use --force)"; continue
  fi
  rm -rf "$target"
  cp -r "$d" "$target"
  find "$target" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null || true
  echo "ok    $name"
  count=$((count+1))
done

echo
echo "Installed $count skill(s) to $DEST"
echo "Restart/reload Claude Code so it re-scans the skills directory."
