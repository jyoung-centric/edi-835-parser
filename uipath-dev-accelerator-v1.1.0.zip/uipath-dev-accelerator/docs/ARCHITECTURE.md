# Architecture & design rationale

## The core problem

UiPath workflows are Windows Workflow Foundation XAML. That format is hostile to
LLMs in both directions:

- **Reading** — a file is dominated by designer view-state (`HintSize`, `IdRef`,
  `ViewState` dictionaries) and two large `TextExpression` boilerplate lists. A
  497 KB `Main.xaml` may hold only a few KB of actual logic. Reading raw XAML
  burns context for almost no signal.
- **Writing** — hand-authored XAML breaks easily (an undeclared namespace prefix,
  a wrong type ref) and then Studio refuses to open the file. Free-form LLM
  generation of whole workflows is the *least* reliable path.

Every design decision follows from one principle:

> **Never let the model touch raw XAML when structure will do.**
> Deterministic scripts handle the mechanical majority; the model spends judgment
> only on genuine logic; and grounding facts come from the project, never invention.

## The 85 / 15 split (author)

A workflow file decomposes into:

- **~85% deterministic scaffold** — root element + namespace block, the two
  `TextExpression` lists, the `x:Members` argument block. This is produced
  mechanically by `new_workflow.py` from a project profile (derived from
  `project.json`) and can't be hallucinated. View-state (`HintSize`/`IdRef`) is
  omitted — Studio regenerates it on open.
- **~15% activity tree** — the logic. Composed from vetted, view-state-stripped
  snippets in `uipath-author/reference/fragments.xaml`, following the VB
  expression rules in `expression-syntax.md`. Then `validate_xaml.py` checks the
  result is well-formed, rooted, and has every used prefix declared.

`new_workflow.py` auto-declares optional namespace prefixes (`sd:`, `s:`, `sl:`,
`njl:`, `uix:`) whenever the args or body use them — closing the most common
"Studio won't open it" failure.

## Grounding: static + live

A story states business intent, not UI mechanics. Turning it into correct
automation requires knowing what the project *actually contains*. Two sources:

1. **Static index** (`project_index.py`) — parses a project into: type
   (REFramework?), existing workflows + typed args, config keys, applications,
   screens→elements (real selectors), and dynamic selectors. This lets the planner
   distinguish REUSE (already exists) from NEW, and map UI steps to real selectors.
2. **Live index** (`verify_grounding.py`) — the cross-wire to
   `uipath-orchestrator-api`. It resolves the chain
   `config key → Orchestrator Asset → value → (if a queue name) QueueDefinitions`,
   turning "these names probably exist" into confirmed facts. Degrades to an
   offline "confirm-these" list when no credentials are present.

**The grounding rule** (shared by plan and selectors): never fabricate a selector,
workflow, or config key. Reference the index, or flag a GAP for a human to resolve
in discourse. A plausible-but-wrong selector fails at the worst time.

## The pipeline

```
story → PLAN → (discourse) → approved Manifest → GENERATE → VALIDATE
        │                                          │
        ├ project_index.py   (static grounding)    ├ build_from_manifest.py  (glue)
        ├ verify_grounding.py (live grounding) ─────┤   └ new_workflow.py (scaffold)
        └ produces Plan Manifest (JSON)             └ validate_xaml.py
```

- **PLAN** decomposes the story into artifacts, marks each REUSE/NEW/MODIFY,
  grounds UI steps, and surfaces gaps/ambiguities/anomalies (duplicate workflows,
  class/file mismatches, missing assets) for the user to resolve. Output: a Plan
  Manifest (`examples/manifest.schema.json`).
- **GENERATE** (`build_from_manifest.py`) drives the author skill per NEW workflow:
  scaffolds it with the planned arguments and an `InvokeWorkflowFile` stub for each
  `invokes` edge (deterministic from the plan), steps as TODO comments, then
  validates. REUSE/MODIFY are reported, never overwritten.

The value is that the plan usually shows a story is 70–90% existing pieces; the
system names the small genuinely-new surface and wires it, rather than
regenerating what's already there.

## Why scripts, not prompts

Each skill's `SKILL.md` gives Claude the *when* and *how*; the deterministic work
lives in Python scripts (stdlib only, no pip). This keeps behavior reproducible,
testable (`tests/`), and cheap — Claude orchestrates and fills logic, scripts do
the mechanical heavy lifting. Skills are installed as siblings so the plan→api
cross-wire resolves by relative path both in-repo and post-install.

## Provenance

Fragments, conventions, and endpoint curation were seeded from real projects —
a postpay EFT **dispatcher** (queue/asset/transaction patterns, custom data
models) and an HC360 **REFramework performer** (Java-app selectors, DataFiles
structure) — plus the Orchestrator API v20.0 swagger. That makes the bundled
examples project-validated rather than generic, while the scripts themselves stay
project-agnostic.
