# Usage — worked commands

Every script is `python3 <script> --help`-friendly. Paths below assume you run
from a skill dir or give absolute paths. `PROJECT` = a UiPath project directory
(the one containing `project.json`).

## Understand an existing project

```bash
# One-line map of every workflow (class · activity count · invokes · selectors)
python3 skills/uipath-reader/scripts/read_workflow.py PROJECT/Frameworks --summary

# Full outline of a single workflow (args, tree, invokes, config keys)
python3 skills/uipath-reader/scripts/read_workflow.py PROJECT/Main.xaml
python3 skills/uipath-reader/scripts/read_workflow.py PROJECT/Main.xaml --exprs

# UI surface: apps → screens → elements, plus a fragility audit
python3 skills/uipath-selectors/scripts/extract_selectors.py PROJECT
python3 skills/uipath-selectors/scripts/extract_selectors.py PROJECT --audit
```

## Index & ground a project (for planning)

```bash
# Static grounding index (JSON): workflows, args, config keys, screens, selectors
python3 skills/uipath-plan/scripts/project_index.py PROJECT > index.json

# Live grounding — verify assets/queues exist in Orchestrator (needs creds; see below)
python3 skills/uipath-plan/scripts/verify_grounding.py --index index.json --folder 123 > grounding.json
# with no creds it runs OFFLINE and lists the names to confirm manually
```

## Generate workflows from an approved Plan Manifest

```bash
# Preview
python3 skills/uipath-plan/scripts/build_from_manifest.py MANIFEST.json --project PROJECT --dry-run
# Generate + validate (new workflows only; reuse/modify are reported)
python3 skills/uipath-plan/scripts/build_from_manifest.py MANIFEST.json --project PROJECT
```
Manifest shape: `skills/uipath-plan/examples/manifest.schema.json`
Worked example: `skills/uipath-plan/examples/EXAMPLE_manifest.json`

## Author a single workflow directly

```bash
python3 skills/uipath-author/scripts/new_workflow.py \
  --name MyWorkflow --project-json PROJECT/project.json \
  --arg "in_strInput:In:x:String" \
  --arg "io_dt:InOut:sd:DataTable" \
  --body-file body.xaml \
  --out PROJECT/Frameworks/MyWorkflow.xaml
python3 skills/uipath-author/scripts/validate_xaml.py PROJECT/Frameworks/MyWorkflow.xaml
```
Body snippets: `skills/uipath-author/reference/fragments.xaml`.

## Orchestrator API

```bash
export UIPATH_CLIENT_ID=…  UIPATH_CLIENT_SECRET=…  \
       UIPATH_BASE_URL=https://cloud.uipath.com/<org>/<tenant>
python3 skills/uipath-orchestrator-api/scripts/orch_call.py GET  "/odata/QueueDefinitions" --folder 123
python3 skills/uipath-orchestrator-api/scripts/orch_call.py POST "/odata/Queues/UiPathODataSvc.AddQueueItem" \
        --folder 123 --data @item.json

# Regenerate the endpoint references from the bundled swagger
python3 skills/uipath-orchestrator-api/scripts/extract_endpoints.py \
        skills/uipath-orchestrator-api/swagger.json skills/uipath-orchestrator-api/reference
```
Endpoint reference groups: `skills/uipath-orchestrator-api/reference/*.md`.

### Orchestrator credentials
Create an **External Application** (Automation Cloud → Admin → External
Applications) with the `OR.*` scopes you need (Queues, Assets, Jobs, Folders,
Monitoring, Execution). Use its client id/secret as `UIPATH_CLIENT_ID` /
`UIPATH_CLIENT_SECRET`. Resolve `--folder` ids via
`reference/folders-discovery.md` (`Folders_GetAllForCurrentUser`).
