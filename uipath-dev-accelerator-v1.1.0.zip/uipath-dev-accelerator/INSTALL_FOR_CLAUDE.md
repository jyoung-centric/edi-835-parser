# Install runbook — for Claude Code

You (Claude) are being asked to install the **UiPath Dev Accelerator** skills. This
file is the runbook. Follow it top to bottom, then report the result to the user.

## What this is
A library of Claude Code skills for UiPath development (plan a user story, author
valid `.xaml`, read/audit existing workflows, call Orchestrator, init a project
CLAUDE.md). Installing = copying each `skills/<name>/` directory into a Claude Code
skills directory so you discover them next session.

## Preconditions (check, don't assume)
1. You are running from inside the unzipped library root (the dir that contains
   `install.ps1`, `install.sh`, and `skills/`). If not, `cd` there first.
2. **Python 3** must be on PATH — every script is Python 3 (stdlib only, no pip).
   Check with `python --version` / `py --version` (Windows) or `python3 --version`.
   If missing, tell the user to install Python 3 (python.org, "Add to PATH") and stop.

## Install steps
1. **Pick scope with the user if unclear** (default = User):
   - **User** — available in every project on this machine.
   - **Project** — scoped to one UiPath project (`<project>\.claude\skills`).
2. **Run the installer for the OS:**
   - Windows / PowerShell:
     ```powershell
     .\install.ps1                       # User scope (default)
     .\install.ps1 -Scope Project -ProjectPath C:\path\to\UiPathProject
     .\install.ps1 -Force                # overwrite an existing install
     ```
   - Linux / macOS:
     ```bash
     ./install.sh                        # User scope
     ./install.sh --scope project /path/to/UiPathProject
     ./install.sh --force
     ```
   The installer copies every skill (as siblings — required for the
   plan→orchestrator-api cross-wire), skips existing ones unless `-Force`, and
   warns if Python isn't found.
3. **Verify** by running the self-tests (no UiPath/network/creds needed):
   ```powershell
   python .\tests\run_tests.ps1     # Windows
   ```
   ```bash
   bash tests/run_tests.sh          # Linux/macOS
   ```
   Expect the final line `RESULT: N passed, 0 failed`. If any fail, report the
   failing test names to the user and stop — do not claim success.
4. **Reload skills** — tell the user to restart / reload their Claude Code session
   so the new skills directory is re-scanned. (You cannot load them into the
   current session yourself.)

## After install — report to the user
- Which scope and directory you installed to, and the skills installed:
  `uipath-plan, uipath-author, uipath-reader, uipath-selectors,
  uipath-orchestrator-api, uipath-init`.
- Offer to **initialize a CLAUDE.md** for their UiPath project (next section).
- Surface the two things that need **live UiPath** to validate (this build was
  tested structurally only):
  1. Open a generated `.xaml` in UiPath Studio to confirm it loads/relays out.
  2. Set `UIPATH_CLIENT_ID` / `UIPATH_CLIENT_SECRET` / `UIPATH_BASE_URL` (an
     Automation Cloud External App with `OR.*` scopes) to exercise the
     Orchestrator client and live grounding.

## Initialize a project CLAUDE.md (recommended)
Once installed, from inside (or pointing at) a UiPath project, run the `uipath-init`
skill's script to generate a project-tailored `CLAUDE.md` so future sessions are
grounded in that project:
```bash
python3 <skills>/uipath-init/scripts/init_claude_md.py /path/to/UiPathProject
```
(`<skills>` = the skills dir you installed into, e.g. `%USERPROFILE%\.claude\skills`.)
Review the generated `CLAUDE.md`, then commit it with the project.
