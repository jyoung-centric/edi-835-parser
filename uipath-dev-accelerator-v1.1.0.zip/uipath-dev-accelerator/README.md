# UiPath Dev Accelerator

A library of **Claude Code skills** that accelerate UiPath development — turning a
user story into grounded, valid, Studio-openable automation, and making existing
UiPath projects fast to read, ground against, and integrate with Orchestrator.

The design principle throughout: **UiPath XAML is verbose and hostile to LLMs, so
never let the model touch raw XAML when structure will do.** Deterministic scripts
handle the mechanical 85% (scaffold, parsing, extraction); the model spends its
judgment only on the 15% that is actual logic — and is never allowed to fabricate
a selector, workflow, or config key that the project doesn't really have.

## The six skills

> **Installing via Claude?** Point your Claude Code agent at `INSTALL_FOR_CLAUDE.md` —
> a step-by-step runbook it can follow to install, verify, and report.

| Skill | Does | Key scripts |
|---|---|---|
| **uipath-plan** | Story → decompose into artifacts *in dialogue* → ground (static + live Orchestrator) → approved Plan Manifest → hand off to author | `project_index.py`, `verify_grounding.py`, `build_from_manifest.py` |
| **uipath-author** | Plan/spec → valid, Studio-openable `.xaml` (deterministic scaffold + fragment-composed body) → validate | `new_workflow.py`, `validate_xaml.py` |
| **uipath-reader** | Any `.xaml` → compact outline (args, tree, invokes, config, selectors) at a fraction of the tokens | `read_workflow.py` |
| **uipath-selectors** | Extract + catalog + **audit** UI selectors (app → screen → element); flag dynamic/brittle ones | `extract_selectors.py` |
| **uipath-orchestrator-api** | Call Orchestrator correctly — curated endpoint refs + authenticated client (token + folder header) | `extract_endpoints.py`, `orch_call.py` |
| **uipath-init** | Generate a project-tailored `CLAUDE.md` so future sessions are grounded in the project | `init_claude_md.py` |

## How they connect

```
                       ┌─────────────────────────────────────────────┐
  USER STORY ─────────▶│ uipath-plan                                 │
                       │  project_index.py ─── static grounding ─────┼──▶ uipath-reader
                       │  verify_grounding.py ─ live grounding ───────┼──▶ uipath-orchestrator-api
                       │  (discourse: confirm gaps with the user)     │      (asset/queue existence)
                       │  → approved Plan Manifest (JSON)             │──▶ uipath-selectors
                       │  build_from_manifest.py ────────────────────┼──▶ uipath-author
                       └─────────────────────────────────────────────┘      (scaffold + validate)
```

`verify_grounding.py` catches, at plan time, things like *"asset
`OrchestratorQueueName_ChargeCodeDetails` = `HC360_ChargeCodes_TYPO` but no queue
by that name exists"* — a config typo that would otherwise fail in production.

## Install (Windows)

```powershell
# All projects on this machine (default):
.\install.ps1

# One project only:
.\install.ps1 -Scope Project -ProjectPath C:\src\MyUiPathProject

# Overwrite an existing install:
.\install.ps1 -Force
```

Linux/macOS: `./install.sh` (add `--scope project <DIR>` or `--force`).

The installer copies each `skills/<name>/` into the Claude Code skills directory
(`%USERPROFILE%\.claude\skills` for User scope, `<project>\.claude\skills` for
Project scope). Skills are installed as **siblings** — required, because the
plan→orchestrator-api cross-wire resolves its neighbor by relative path.
Restart/reload Claude Code afterward so it re-scans skills.

### Requirements
- **Claude Code** (skills are discovered from the skills directory).
- **Python 3** on PATH — every script is Python 3, stdlib only (no pip installs).
  The installer warns if Python isn't found but still copies the files.

## Verify the install / run the self-tests

```powershell
python .\tests\run_tests.ps1     # Windows
```
```bash
bash tests/run_tests.sh          # Linux/macOS
```
No UiPath install, network, or Orchestrator credentials required — the suite runs
against bundled fixtures and covers all six skills plus the end-to-end hand-off.

## Typical workflow

1. **Understand** an existing project — `uipath-reader` on the folder (`--summary`),
   `uipath-selectors` for the UI surface.
2. **Plan** a user story — `uipath-plan` indexes the project, grounds the story
   (statically, and live against Orchestrator if creds are set), and produces a
   Plan Manifest after resolving gaps with you.
3. **Generate** — `build_from_manifest.py` scaffolds the new workflows (pre-wired
   invokes), `uipath-author` fills the bodies from vetted fragments; every file is
   validated.
4. **Integrate** — `uipath-orchestrator-api` for any queue/asset/job API work.

See `docs/ARCHITECTURE.md` for the full design rationale and `docs/USAGE.md` for
worked commands.

## Layout

```
uipath-dev-accelerator/
  install.ps1 / install.sh        installers (Windows / *nix)
  README.md
  VERSION
  docs/       ARCHITECTURE.md, USAGE.md
  tests/      run_tests.ps1 / run_tests.sh + fixtures/
  skills/
    uipath-plan/          SKILL.md · scripts/ · examples/ (manifest schema + worked example)
    uipath-author/        SKILL.md · scripts/ · reference/ (anatomy, expressions, fragments) · examples/
    uipath-reader/        SKILL.md · scripts/
    uipath-selectors/     SKILL.md · scripts/ · reference/ (selector idioms)
    uipath-orchestrator-api/  SKILL.md · scripts/ · reference/ (5 endpoint groups) · swagger.json
    uipath-init/          SKILL.md · scripts/ (generate a project CLAUDE.md)
```

Top-level `INSTALL_FOR_CLAUDE.md` is a runbook for a Claude Code agent doing the install.

## Portability & provenance

Nothing is hardcoded to one project — every script takes a project path / project.json
and adapts. Conventions and fragments were **seeded from real UiPath projects**
(a dispatcher and an HC360 REFramework performer) so the examples are
project-validated rather than generic. The endpoint references are distilled from
the UiPath Orchestrator API v20.0 swagger (bundled, regenerable).
