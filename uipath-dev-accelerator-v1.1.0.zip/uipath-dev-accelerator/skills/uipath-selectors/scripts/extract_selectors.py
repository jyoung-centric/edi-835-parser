#!/usr/bin/env python3
"""
extract_selectors.py — build a selector catalog for a UiPath project, grouped by
APPLICATION → SCREEN (window) → ELEMENT, and flag runtime-built (dynamic)
selectors for verification.

UI-automation performers target real applications through selectors. Understanding
or auditing that automation means seeing which apps, windows, and controls it
drives — and catching the fragile bits (hardcoded titles, dynamic selectors,
duplicated/near-duplicate targets). This tool produces that catalog from the
project's .xaml, with no UiPath install and no Object Repository parsing required
(it reads selectors wherever they appear).

Usage:
    extract_selectors.py PROJECT_DIR                 # grouped catalog (text)
    extract_selectors.py PROJECT_DIR --json          # machine-readable
    extract_selectors.py PROJECT_DIR --audit         # only the risk findings
"""
import argparse, collections, glob, json, os, re, sys

SEL_RE = re.compile(r'(?:Selector|FullSelector|FuzzySelector)="([^"]*)"')

def un(s):
    for a, b in [('&quot;', '"'), ('&gt;', '>'), ('&lt;', '<'),
                 ('&amp;', '&'), ('&#xA;', ''), ('&#xD;', '')]:
        s = s.replace(a, b)
    return s.strip()

def window_of(raw):
    w = re.search(r"<wnd\b[^>]*>", raw)
    if not w:
        return None
    c = re.search(r"cls='([^']*)'", w.group(0))
    t = re.search(r"title='([^']*)'", w.group(0))
    a = re.search(r"app='([^']*)'", raw)
    return (a.group(1) if a else '', c.group(1) if c else '', t.group(1) if t else '')

def leaf(raw):
    nodes = re.findall(r'<[^>]+>', raw)
    n = nodes[-1] if nodes else raw
    cls = re.search(r"cls='([^']*)'", n)
    nm = re.search(r"name='([^']*)'", n)
    role = re.search(r"role='([^']*)'", n)
    parts = []
    if cls: parts.append(f"cls={cls.group(1)}")
    if nm: parts.append(f"name='{nm.group(1)}'")
    if role: parts.append(f"[{role.group(1)}]")
    return ' '.join(parts) or n[:60]

def build(root):
    files = sorted(glob.glob(os.path.join(root, "**/*.xaml"), recursive=True))
    screens = collections.defaultdict(lambda: collections.defaultdict(set))
    dynamic, hardcoded_titles, apps = [], [], collections.Counter()
    per_file_windows = collections.defaultdict(collections.Counter)

    for f in files:
        base = os.path.basename(f)
        try:
            txt = open(f, encoding='utf-8').read()
        except Exception:
            continue
        local = []
        for m in SEL_RE.finditer(txt):
            raw = un(m.group(1))
            if not raw:
                continue
            if raw.startswith('['):
                dynamic.append({"expr": raw, "file": base})
                continue
            if raw == '{x:Null}':
                continue
            w = window_of(raw)
            local.append((raw, w))
            if w:
                per_file_windows[base][w] += 1
        dom = per_file_windows[base].most_common(1)
        dom = dom[0][0] if dom else None
        for raw, w in local:
            if w:
                apps[w[0] or 'unknown'] += 1
                screens[w][leaf(raw)].add(base)
                # a concrete title (no wildcard) anchored to a window = brittle
                if w[2] and '*' not in w[2] and w[2] not in ('', '?'):
                    hardcoded_titles.append({"app": w[0], "title": w[2], "file": base})
            elif dom:
                screens[dom][leaf(raw)].add(base)
            else:
                screens[('', '(relative)', '')][leaf(raw)].add(base)

    catalog = collections.defaultdict(list)
    for (app, wcls, ttl), elems in screens.items():
        catalog[app or 'jp2launcher.exe'].append({
            "window_cls": wcls, "title": ttl,
            "count": sum(len(v) for v in elems.values()),
            "elements": [{"desc": d, "files": sorted(fs)} for d, fs in sorted(elems.items())],
        })
    for app in catalog:
        catalog[app].sort(key=lambda s: -s["count"])
    return {
        "applications": dict(apps),
        "screens_by_app": dict(catalog),
        "dynamic_selectors": dynamic,
        "hardcoded_titles": hardcoded_titles,
    }

def print_catalog(idx):
    print(f"APPLICATIONS: " + ", ".join(f"{a} ({n})" for a, n in
          sorted(idx["applications"].items(), key=lambda x: -x[1])))
    for app, screens in idx["screens_by_app"].items():
        print(f"\n{'='*74}\nAPP: {app}\n{'='*74}")
        for s in screens:
            print(f"\n  ▼ <wnd cls='{s['window_cls']}' title='{s['title']}'>  "
                  f"({s['count']} refs, {len(s['elements'])} distinct)")
            for e in s["elements"]:
                print(f"      • {e['desc']}")
    print_audit(idx)

def print_audit(idx):
    print(f"\n{'='*74}\nAUDIT FINDINGS\n{'='*74}")
    dyn = idx["dynamic_selectors"]
    print(f"\nDynamic (runtime-built) selectors — verify the expression resolves: {len(dyn)}")
    for d in dyn[:20]:
        print(f"   • {d['expr']}   ({d['file']})")
    ht = idx["hardcoded_titles"]
    uniq = sorted({(h['app'], h['title']) for h in ht})
    print(f"\nHardcoded window titles (no wildcard — brittle to caption changes): {len(uniq)}")
    for app, title in uniq[:20]:
        print(f"   • {app} :: title='{title}'")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("project")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--audit", action="store_true")
    a = ap.parse_args()
    idx = build(a.project)
    if a.json:
        json.dump(idx, sys.stdout, indent=2, default=lambda o: sorted(o) if isinstance(o, set) else o)
        print()
    elif a.audit:
        print_audit(idx)
    else:
        print_catalog(idx)

if __name__ == "__main__":
    main()
