---
name: uipath-selectors
description: >
  Extract, catalog, and audit UiPath UI-automation selectors. Use when working
  with a UiPath performer that automates a desktop or web application — to see
  which apps/screens/controls it drives, to ground new automation in EXISTING
  selectors (never invent them), or to audit selectors for fragility (hardcoded
  window titles, runtime-built selectors, duplicates). Groups selectors by
  application → screen → element.

---

# uipath-selectors

UI-automation performers target real applications through selectors embedded in
`Click` / `TypeInto` / `NApplicationCard` / `Get*` activities. This skill turns
that scattered set into a structured catalog and flags the fragile parts.

## When to use

- **Grounding new automation** — before authoring a step that clicks/types, find
  the REAL selector for that screen/control in the catalog. If it isn't there,
  it's a gap to record in the Object Repository — do not fabricate a selector.
- **Understanding a performer** — what apps/windows/controls does it drive.
- **Auditing** — surface brittle selectors before they break in production.

## Usage

```bash
# Full catalog: application → screen (window) → elements
python3 scripts/extract_selectors.py /path/to/uipath/project

# Just the risk findings
python3 scripts/extract_selectors.py /path/to/uipath/project --audit

# Machine-readable (for uipath-plan grounding)
python3 scripts/extract_selectors.py /path/to/uipath/project --json > selectors.json
```

## Output

- **Catalog** — grouped `APP → <wnd cls,title> → element descriptors`, each with
  the files that use it. Windowed selectors anchor the screen; relative (child)
  selectors are attributed to their file's dominant window.
- **Audit** —
  - *Dynamic selectors*: runtime-built (`[expr]` / `string.Format(...)`). These
    can't be statically confirmed — the catalog shows the expression so you can
    verify it resolves to a real target.
  - *Hardcoded window titles*: concrete titles with no `*` wildcard — brittle to
    caption/localization changes. Candidates for wildcarding.

## Grounding rule (shared with uipath-plan)

**Never invent a selector.** Reference one from the catalog, or flag the missing
element as a gap for a human to record in the Object Repository. A plausible-but-
wrong selector produces automation that fails at the worst time.

## Selector idioms

See `reference/selector-idioms.md` for the anatomy of UiPath selectors (window
anchor + element path), the common Java/`Hcn*`, `wnd`, `html`/`webctrl` forms,
wildcard/anchor tactics, and when to prefer fuzzy vs strict.

## Notes

- Pure static parse; no UiPath install or Object Repository access required.
- Complements `uipath-reader` (which merely flags `[selector]`) by decoding them.
- The extraction logic mirrors what `uipath-plan`'s `project_index.py` uses, so a
  story is grounded against the same selectors this catalog reports.
