# UiPath selector idioms

A UiPath selector is XML: a **window anchor** followed by an **element path**.
Each `<node attr='value' … />` narrows the search. The runtime matches
attributes; `*` and `?` are wildcards.

```
<wnd app='jp2launcher.exe' cls='SunAwtFrame' title='*HomeCare*360*Login*' />
<java cls='HcnPasswordField' role='password text' />
└─ window anchor (which app + top window) ──┘ └─ element within it ─┘
```

## Node types you'll see

| Node | Meaning | Typical attrs |
|---|---|---|
| `wnd` | Win32 window (frame/dialog) | `app`, `cls`, `title` |
| `java` | Java/Swing/AWT control | `cls`, `role`, `name`, `virtualname`, `tableRow`/`tableCol` |
| `ctrl` | generic UIA control | `role`, `name`, `automationid` |
| `html` / `webctrl` | browser element | `tag`, `aaname`, `id`, `class`, `parentid` |
| `uia` | modern UIA | `name`, `role`, `automationid` |

## Attribute tactics (robust vs brittle)

- **`app`** — always pin the executable (`jp2launcher.exe`, `chrome.exe`). Cheap,
  strong disambiguation.
- **`cls`** — window/control class. Stable for custom widget sets (`Hcn*`,
  `SunAwtFrame`/`SunAwtDialog`). Prefer over title when available.
- **`title` / `aaname` / `name`** — visible captions. **Brittle** — they change
  with data, localization, and state. Wildcard them: `title='*HomeCare*360*'`
  not `title='HomeCare 360°'`. The audit flags un-wildcarded titles.
- **`virtualname`** — a stable developer-assigned id (e.g. `taMessage`,
  `tblTop1`). **Prefer it** when present; it survives caption changes.
- **`role`** — semantic role (`push button`, `text`, `table`, `label`). Good
  secondary filter, rarely unique alone.
- **`idx`** — positional index. **Last resort** — order changes break it.

## Table-row targeting (dynamic)

Grids are addressed by row/col, usually built at runtime:
```
string.Format("<java cls='HcnTable' role='table' virtualname='tblTop1' />" &
              "<java role='label' tableCol='0' tableRow='{0}' />", currentRowIndex)
```
These are **dynamic selectors** — the catalog lists them but can't confirm they
resolve; verify the index expression is 0- vs 1-based and bounded.

## Strict vs fuzzy

- **Strict (`Selector`/`FullSelector`)** — exact attribute match. Fast,
  predictable; use when the app exposes stable ids/classes (like `Hcn*`).
- **Fuzzy (`FuzzySelector`) / anchors** — tolerant matching for shifting UIs
  (some web apps). More resilient, slower, can mis-target. Prefer strict for the
  Java desktop apps here; reserve fuzzy for volatile HTML.

## Grounding checklist (when authoring a new UI step)

1. Find the target screen in the catalog (`extract_selectors.py`).
2. Reuse an existing element selector verbatim if one matches.
3. If the element isn't catalogued → **GAP**: record it in the Object Repository;
   do not hand-write a selector from guesswork.
4. Prefer `virtualname`/`cls` over `title`/`name`; wildcard any caption you must
   use; avoid `idx`.
