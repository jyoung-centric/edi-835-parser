---
name: uipath-orchestrator-api
description: >
  Call the UiPath Orchestrator REST API correctly. Use when working with
  Orchestrator endpoints — queues, transactions, queue items, assets, jobs,
  processes/releases, folders, robot logs — whether constructing a raw HTTP
  call, a UiPath OrchestratorHttpRequest activity, or scripting ops tasks.
  Provides distilled per-domain endpoint references (method, path, params,
  request/response shape) plus an authenticated client and the auth + folder-
  header conventions that every call needs.
---

# uipath-orchestrator-api

Distilled from the UiPath Orchestrator API v20.0 swagger (344 paths / 415 ops →
the ~33 endpoints these RPA processes actually use). The full swagger is huge and
mostly irrelevant to dispatcher/performer work; this skill carries only the useful
subset, grounded in what the projects do (populate queues, drive transactions,
read assets, start/monitor jobs).

## Auth — every call needs this

1. **Bearer token** via OAuth2 client-credentials (Automation Cloud *External
   Application*). POST to `https://cloud.uipath.com/identity_/connect/token` with
   `grant_type=client_credentials`, `client_id`, `client_secret`, and a `scope`
   of the `OR.*` scopes you need (e.g. `OR.Queues OR.Assets OR.Jobs`).
2. **Folder header.** Folder-scoped resources (queues, assets, jobs, queue items)
   require `X-UIPATH-OrganizationUnitId: <folderId>`. Calls that omit it silently
   resolve against the wrong/no folder. Resolve the id via
   `folders-discovery.md` (`Folders_GetAllForCurrentUser`).
3. **Base URL** is per org/tenant: `https://cloud.uipath.com/<org>/<tenant>`.

Never hardcode credentials. The client reads them from env vars — same principle
as the robots reading queue names from Config assets.

## Using the client

```bash
export UIPATH_CLIENT_ID=…  UIPATH_CLIENT_SECRET=…  \
       UIPATH_BASE_URL=https://cloud.uipath.com/myorg/mytenant
python3 scripts/orch_call.py GET  "/odata/QueueDefinitions" --folder 123
python3 scripts/orch_call.py POST "/odata/Queues/UiPathODataSvc.AddQueueItem" \
        --folder 123 --data @item.json
python3 scripts/orch_call.py GET  "/odata/QueueItems" \
        --folder 123 --query "\$filter=Status eq 'New'&\$top=10"
```

The client handles token fetch, the folder header, OData query passthrough, and
prints `HTTP <status>` + JSON. It's a dev/ops helper for exploring and scripting —
robots use the built-in UiPath activities, not this client.

## Endpoint references (curated)

| File | Covers | Maps to project activity |
|---|---|---|
| `reference/queues-transactions.md` | AddQueueItem, BulkAddQueueItems, StartTransaction, SetTransactionResult/Progress, list/get/delete QueueItems, QueueDefinitions, comments | `AddQueueItem`, `GetQueueItems`, `AddTransactionItem`, `SetTransactionStatus` |
| `reference/assets.md` | GetRobotAssetByNameForRobotKey, GetAssetByName, list/get/create/update/delete Assets | `GetRobotAsset`, `SetAsset` |
| `reference/jobs-processes.md` | StartJobs, list/get/stop Jobs, Releases, ProcessSchedules | (dispatcher launch / monitoring) |
| `reference/folders-discovery.md` | resolve folder ids for the header | (prereq for all folder-scoped calls) |
| `reference/logs-monitoring.md` | RobotLogs, job-by-id | (run monitoring / triage) |

Each entry lists method, path, `operationId`, params (with `*`=required and
`in` location), request `body` shape, and `returns` shape — enough to construct
a correct call without reopening the 1.6 MB swagger.

## Regenerating / extending

`scripts/extract_endpoints.py swagger.json reference/` rebuilds the references.
To add endpoints, append their `operationId`s to the `GROUPS` map. The extractor
reports any unresolved ids (operationId drift between API versions), so the
references never silently go stale.

## Notes / gotchas

- **OData conventions:** list endpoints accept `$filter`, `$top`, `$skip`,
  `$orderby`, `$expand`, `$select`. Always page large queues with `$top`/`$skip`.
- **Transaction lifecycle** (mirrors the robot's): `StartTransaction` →
  `SetTransactionProgress` (optional, while In Progress) → `SetTransactionResult`
  with `IsSuccessful` or an exception payload (Business vs Application).
- **AddQueueItem vs BulkAddQueueItems:** the dispatcher adds one item per record;
  use Bulk for large input files to cut round-trips (note its `commitType`).
- **EnforceUniqueReference:** if a queue enforces it, AddQueueItem returns a
  conflict for duplicate `Reference` — handle it, don't retry blindly.
- This is the **cloud v20.0** surface; on-prem/standalone paths match but the
  identity/token URL and base URL differ.
