#!/usr/bin/env python3
"""
extract_endpoints.py — distill the 1.6 MB Orchestrator swagger into compact,
per-domain endpoint references for the skill. Pulls only the operations we
curate as useful, with method, path, summary, params, request/response shape.

Usage:
    extract_endpoints.py swagger.json OUTDIR
"""
import json, os, re, sys

# Curated useful operationIds, grouped into reference files. This is the
# "useful endpoints" decision — grounded in what the dispatcher/performer do
# (queues, transactions, assets, jobs, folders, logs) plus the essentials to
# discover ids (releases, queue definitions).
GROUPS = {
    "queues-transactions": [
        "Queues_AddQueueItem", "Queues_BulkAddQueueItems",
        "Queues_StartTransaction", "Queues_SetTransactionResultById",
        "QueueItems_SetTransactionProgressById",
        "QueueItems_Get", "QueueItems_GetById",
        "QueueItems_DeleteById", "QueueItemComments_Post",
        "QueueDefinitions_Get", "QueueDefinitions_Post",
    ],
    "assets": [
        "Assets_GetRobotAssetByNameForRobotKey",
        "Assets_GetRobotAssetByRobotId", "Assets_GetAssetByName",
        "Assets_Get", "Assets_GetById",
        "Assets_Post", "Assets_PutById", "Assets_DeleteById",
    ],
    "jobs-processes": [
        "Jobs_StartJobs", "Jobs_Get", "Jobs_GetById",
        "Jobs_StopJobById", "Jobs_StopJobs",
        "Releases_Get", "Releases_GetById",
        "ProcessSchedules_Get",
    ],
    "folders-discovery": [
        "Folders_GetAllForCurrentUser",
        "Folders_Get", "Folders_GetById",
    ],
    "logs-monitoring": [
        "RobotLogs_Get", "RobotLogs_GetTotalCount",
        "Jobs_GetById",
    ],
}

def ref_name(ref):
    return ref.split("/")[-1] if ref else None

def schema_brief(schema, defs, depth=0, seen=None):
    """Render a request/response schema down to field:type lines (shallow)."""
    if schema is None or depth > 2:
        return ""
    seen = seen or set()
    if "$ref" in schema:
        n = ref_name(schema["$ref"])
        if n in seen:
            return f"{n}{{…}}"
        seen = seen | {n}
        schema = defs.get(n, {})
        prefix = f"{n} "
    else:
        prefix = ""
    t = schema.get("type")
    if t == "array":
        return "[" + schema_brief(schema.get("items", {}), defs, depth + 1, seen) + "]"
    props = schema.get("properties")
    if not props:
        return prefix + (t or "object")
    fields = []
    for k, v in list(props.items())[:12]:
        vt = v.get("type") or (ref_name(v.get("$ref")) if v.get("$ref") else "obj")
        if vt == "array":
            it = v.get("items", {})
            vt = "[" + (it.get("type") or ref_name(it.get("$ref")) or "obj") + "]"
        fields.append(f"{k}:{vt}")
    more = "…" if len(props) > 12 else ""
    return prefix + "{ " + ", ".join(fields) + more + " }"

def main(swagger, outdir):
    d = json.load(open(swagger))
    defs = d.get("definitions", {})
    # index operations by operationId
    byid = {}
    for path, methods in d["paths"].items():
        for m, op in methods.items():
            if isinstance(op, dict) and "operationId" in op:
                byid[op["operationId"]] = (m.upper(), path, op)

    os.makedirs(outdir, exist_ok=True)
    found, missing = 0, []
    for group, oids in GROUPS.items():
        lines = [f"# Orchestrator API — {group}\n",
                 "_Distilled from UiPath Orchestrator API v20.0. "
                 "All calls need the Bearer token; folder-scoped calls also need "
                 "the `X-UIPATH-OrganizationUnitId` header (see SKILL.md)._\n"]
        for oid in oids:
            if oid not in byid:
                missing.append(oid); continue
            found += 1
            m, path, op = byid[oid]
            lines.append(f"\n## {m} `{path}`")
            if op.get("summary"):
                lines.append(f"{op['summary'].strip()}")
            lines.append(f"`operationId: {oid}`")
            # params
            qp, body = [], None
            for prm in op.get("parameters", []):
                if not isinstance(prm, dict):
                    continue
                loc = prm.get("in")
                if loc == "body":
                    body = prm.get("schema")
                elif loc in ("query", "path", "header"):
                    req = "*" if prm.get("required") else ""
                    qp.append(f"{prm.get('name')}{req} ({loc})")
            if qp:
                lines.append("- **params:** " + ", ".join(qp))
            if body is not None:
                lines.append("- **body:** " + schema_brief(body, defs))
            # 200/201 response
            resp = op.get("responses", {})
            ok = resp.get("200") or resp.get("201") or {}
            if ok.get("schema"):
                lines.append("- **returns:** " + schema_brief(ok["schema"], defs))
        out = os.path.join(outdir, f"{group}.md")
        open(out, "w").write("\n".join(lines) + "\n")
        print(f"wrote {out}  ({len(oids)} curated, "
              f"{sum(1 for o in oids if o in byid)} resolved)")
    print(f"\nTOTAL resolved: {found}")
    if missing:
        print("UNRESOLVED operationIds (name drift — check swagger):")
        for mo in missing:
            print("  -", mo)

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
