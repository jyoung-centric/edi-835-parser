#!/usr/bin/env python3
"""
orch_call.py — thin authenticated client for the UiPath Orchestrator API.

Handles the two things every call needs and that are easy to get wrong:
  1. OAuth2 client-credentials token (Automation Cloud external app), cached.
  2. The X-UIPATH-OrganizationUnitId folder header for folder-scoped calls.

Credentials come from env vars (never hardcode — see the dispatcher's habit of
reading queue names from Config assets, same principle):
  UIPATH_CLIENT_ID, UIPATH_CLIENT_SECRET, UIPATH_SCOPE (default OR.* scopes),
  UIPATH_BASE_URL  (e.g. https://cloud.uipath.com/<org>/<tenant>)
  UIPATH_IDENTITY  (default https://cloud.uipath.com/identity_/connect/token)
  UIPATH_FOLDER_ID (optional default folder)

Usage:
  orch_call.py GET  "/odata/QueueDefinitions"
  orch_call.py POST "/odata/Queues/UiPathODataSvc.AddQueueItem" \
       --folder 123 --data @item.json
  orch_call.py GET  "/odata/QueueItems" --query '$filter=Status eq '\''New'\'''

This is a dev/ops helper for exploring and scripting Orchestrator — the robots
themselves use the built-in UiPath activities, not this client.
"""
import argparse, json, os, sys, urllib.parse, urllib.request

TOKEN_CACHE = os.path.expanduser("~/.cache/uipath_orch_token.json")

def _post_form(url, form):
    data = urllib.parse.urlencode(form).encode()
    req = urllib.request.Request(url, data=data,
        headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req) as r:
        return json.load(r)

def get_token():
    cid = os.environ.get("UIPATH_CLIENT_ID")
    sec = os.environ.get("UIPATH_CLIENT_SECRET")
    if not cid or not sec:
        sys.exit("set UIPATH_CLIENT_ID and UIPATH_CLIENT_SECRET")
    token_url = os.environ.get("UIPATH_IDENTITY",
        "https://cloud.uipath.com/identity_/connect/token")
    scope = os.environ.get("UIPATH_SCOPE",
        "OR.Queues OR.Assets OR.Jobs OR.Folders OR.Monitoring OR.Execution")
    tok = _post_form(token_url, {
        "grant_type": "client_credentials",
        "client_id": cid, "client_secret": sec, "scope": scope})
    return tok["access_token"]

def call(method, path, folder=None, query=None, body=None):
    base = os.environ.get("UIPATH_BASE_URL")
    if not base:
        sys.exit("set UIPATH_BASE_URL to https://cloud.uipath.com/<org>/<tenant>")
    url = base.rstrip("/") + path
    if query:
        url += ("&" if "?" in url else "?") + query
    headers = {"Authorization": f"Bearer {get_token()}",
               "Content-Type": "application/json"}
    fid = folder or os.environ.get("UIPATH_FOLDER_ID")
    if fid:
        headers["X-UIPATH-OrganizationUnitId"] = str(fid)
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req) as r:
            txt = r.read().decode()
            return r.status, txt
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("method")
    ap.add_argument("path")
    ap.add_argument("--folder", help="X-UIPATH-OrganizationUnitId")
    ap.add_argument("--query", help="raw OData query string, e.g. $top=5")
    ap.add_argument("--data", help="JSON body, inline or @file.json")
    a = ap.parse_args()
    body = None
    if a.data:
        body = json.load(open(a.data[1:])) if a.data.startswith("@") \
               else json.loads(a.data)
    status, txt = call(a.method.upper(), a.path, a.folder, a.query, body)
    print(f"HTTP {status}")
    try:
        print(json.dumps(json.loads(txt), indent=2)[:4000])
    except Exception:
        print(txt[:4000])

if __name__ == "__main__":
    main()
