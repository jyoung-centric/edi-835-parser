# Orchestrator API — folders-discovery

_Distilled from UiPath Orchestrator API v20.0. All calls need the Bearer token; folder-scoped calls also need the `X-UIPATH-OrganizationUnitId` header (see SKILL.md)._


## GET `/api/Folders/GetAllForCurrentUser`
Returns a subset (paginated) of the folders the current user has access to.
The response will be a list of folders;
`operationId: Folders_GetAllForCurrentUser`
- **params:** take (query), skip (query)
- **returns:** PageResultDtoOfCurrentUserFolderDto { PageItems:[CurrentUserFolderDto], Count:integer }

## GET `/odata/Folders`
Gets folders.
`operationId: Folders_Get`
- **params:** $select (query), $expand (query), $filter (query), $orderby (query), $top (query), $skip (query), $count (query)
- **returns:** ODataValueOfIEnumerableOfFolderDto { value:[FolderDto] }

## GET `/odata/Folders({key})`
Gets a single folder, based on its Id.
`operationId: Folders_GetById`
- **params:** key* (path), $select (query), $expand (query)
- **returns:** FolderDto { Key:string, DisplayName:string, FullyQualifiedName:string, Description:string, FolderType:string, IsPersonal:boolean, ProvisionType:string, PermissionModel:string, ParentId:integer, ParentKey:string, FeedType:string, Id:integer }
