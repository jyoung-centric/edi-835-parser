# Orchestrator API — assets

_Distilled from UiPath Orchestrator API v20.0. All calls need the Bearer token; folder-scoped calls also need the `X-UIPATH-OrganizationUnitId` header (see SKILL.md)._


## POST `/odata/Assets/UiPath.Server.Configuration.OData.GetRobotAssetByNameForRobotKey`
Returns the named asset associated to the given robot key.
`operationId: Assets_GetRobotAssetByNameForRobotKey`
- **params:** $select (query), $expand (query), X-UIPATH-OrganizationUnitId (header)
- **body:** AssetsGetRobotByNameAndKeyRequest { robotKey:string, assetName:string, supportsCredentialsProxyDisconnected:boolean }
- **returns:** UserAssetDto { Name:string, ValueType:string, StringValue:string, BoolValue:boolean, IntValue:integer, SecretValue:string, JsonValue:string, CredentialUsername:string, CredentialPassword:string, ExternalName:string, CredentialStoreId:integer, KeyValueList:[CustomKeyValuePair]… }

## GET `/odata/Assets/UiPath.Server.Configuration.OData.GetRobotAssetByRobotId(robotId={robotId},assetName='{assetName}')`
Returns the named asset associated to the given robot Id.
`operationId: Assets_GetRobotAssetByRobotId`
- **params:** robotId* (path), assetName* (path), $select (query), $expand (query), X-UIPATH-OrganizationUnitId (header)
- **returns:** UserAssetDto { Name:string, ValueType:string, StringValue:string, BoolValue:boolean, IntValue:integer, SecretValue:string, JsonValue:string, CredentialUsername:string, CredentialPassword:string, ExternalName:string, CredentialStoreId:integer, KeyValueList:[CustomKeyValuePair]… }

## GET `/api/Assets/name/{name}/value`
Returns the named asset without requiring a robot key. Intended for first-party
service-to-service and direct API callers.
`operationId: Assets_GetAssetByName`
- **params:** name* (path), X-UIPATH-OrganizationUnitId (header)
- **returns:** UserAssetValueDto { Name:string, ValueType:string, Value:string, StringValue:string, BoolValue:boolean, IntValue:integer, SecretValue:string, JsonValue:string, CredentialUsername:string, CredentialPassword:string, ExternalName:string, CredentialStoreId:integer… }

## GET `/odata/Assets`
Get Assets
`operationId: Assets_Get`
- **params:** $select (query), $expand (query), $filter (query), $orderby (query), $top (query), $skip (query), $count (query), X-UIPATH-OrganizationUnitId (header)
- **returns:** ODataValueOfIEnumerableOfAssetDto { value:[AssetDto] }

## GET `/odata/Assets({key})`
Gets a single asset based on its id
`operationId: Assets_GetById`
- **params:** key* (path), $select (query), $expand (query), X-UIPATH-OrganizationUnitId (header)
- **returns:** AssetDto { Key:string, Name:string, CanBeDeleted:boolean, ValueScope:string, ValueType:string, Value:string, StringValue:string, BoolValue:boolean, IntValue:integer, CredentialUsername:string, CredentialPassword:string, SecretValue:string… }

## POST `/odata/Assets`
Creates an asset
`operationId: Assets_Post`
- **params:** X-UIPATH-OrganizationUnitId (header)
- **body:** AssetDto { Key:string, Name:string, CanBeDeleted:boolean, ValueScope:string, ValueType:string, Value:string, StringValue:string, BoolValue:boolean, IntValue:integer, CredentialUsername:string, CredentialPassword:string, SecretValue:string… }
- **returns:** AssetDto { Key:string, Name:string, CanBeDeleted:boolean, ValueScope:string, ValueType:string, Value:string, StringValue:string, BoolValue:boolean, IntValue:integer, CredentialUsername:string, CredentialPassword:string, SecretValue:string… }

## PUT `/odata/Assets({key})`
Edit an asset
`operationId: Assets_PutById`
- **params:** key* (path), X-UIPATH-OrganizationUnitId (header)
- **body:** AssetDto { Key:string, Name:string, CanBeDeleted:boolean, ValueScope:string, ValueType:string, Value:string, StringValue:string, BoolValue:boolean, IntValue:integer, CredentialUsername:string, CredentialPassword:string, SecretValue:string… }

## DELETE `/odata/Assets({key})`
Delete an asset
`operationId: Assets_DeleteById`
- **params:** key* (path), X-UIPATH-OrganizationUnitId (header)
