# Orchestrator API — logs-monitoring

_Distilled from UiPath Orchestrator API v20.0. All calls need the Bearer token; folder-scoped calls also need the `X-UIPATH-OrganizationUnitId` header (see SKILL.md)._


## GET `/odata/RobotLogs`
Gets the robot logs.
`operationId: RobotLogs_Get`
- **params:** $select (query), $expand (query), $filter (query), $orderby (query), $top (query), $skip (query), $count (query), X-UIPATH-OrganizationUnitId (header)
- **returns:** ODataValueOfIEnumerableOfLogDto { value:[LogDto] }

## GET `/odata/RobotLogs/UiPath.Server.Configuration.OData.GetTotalCount`
Gets the total count of robot logs.
This might be different than the size of the count returned by GetRobotLogs which
is limited by the max_result_window parameter for an Elasticsearch source.
`operationId: RobotLogs_GetTotalCount`
- **params:** $select (query), $expand (query), $filter (query), $orderby (query), $top (query), $skip (query), $count (query), X-UIPATH-OrganizationUnitId (header)
- **returns:** ODataValueOfInt64 { value:integer }

## GET `/odata/Jobs({key})`
Gets a single job.
`operationId: Jobs_GetById`
- **params:** key* (path), $select (query), $expand (query), X-UIPATH-OrganizationUnitId (header)
- **returns:** JobDto { Key:string, StartTime:string, EndTime:string, State:string, SubState:string, JobPriority:string, SpecificPriorityValue:integer, Robot:SimpleRobotDto, Release:SimpleReleaseDto, ResourceOverwrites:string, Source:string, SourceType:string… }
