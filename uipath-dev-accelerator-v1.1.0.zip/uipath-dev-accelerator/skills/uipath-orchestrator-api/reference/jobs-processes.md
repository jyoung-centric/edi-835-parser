# Orchestrator API — jobs-processes

_Distilled from UiPath Orchestrator API v20.0. All calls need the Bearer token; folder-scoped calls also need the `X-UIPATH-OrganizationUnitId` header (see SKILL.md)._


## POST `/odata/Jobs/UiPath.Server.Configuration.OData.StartJobs`
Adds a new job and sets it in Pending state for each robot based on the input parameters and notifies the respective robots about the pending job.
`operationId: Jobs_StartJobs`
- **params:** $select (query), $expand (query), $filter (query), $orderby (query), $count (query), X-UIPATH-OrganizationUnitId (header)
- **body:** StartJobsRequest { startInfo:StartProcessDto }
- **returns:** ODataValueOfIEnumerableOfJobDto { value:[JobDto] }

## GET `/odata/Jobs`
Gets Jobs.
`operationId: Jobs_Get`
- **params:** mandatoryPermissions (query), atLeastOnePermissions (query), $select (query), $expand (query), $filter (query), $orderby (query), $top (query), $skip (query), $count (query), X-UIPATH-OrganizationUnitId (header)
- **returns:** ODataValueOfIEnumerableOfJobDto { value:[JobDto] }

## GET `/odata/Jobs({key})`
Gets a single job.
`operationId: Jobs_GetById`
- **params:** key* (path), $select (query), $expand (query), X-UIPATH-OrganizationUnitId (header)
- **returns:** JobDto { Key:string, StartTime:string, EndTime:string, State:string, SubState:string, JobPriority:string, SpecificPriorityValue:integer, Robot:SimpleRobotDto, Release:SimpleReleaseDto, ResourceOverwrites:string, Source:string, SourceType:string… }

## POST `/odata/Jobs({key})/UiPath.Server.Configuration.OData.StopJob`
Cancels or terminates the specified job.
`operationId: Jobs_StopJobById`
- **params:** key* (path), X-UIPATH-OrganizationUnitId (header)
- **body:** StopJobRequest { strategy:string }

## POST `/odata/Jobs/UiPath.Server.Configuration.OData.StopJobs`
Cancels or terminates the specified jobs.
`operationId: Jobs_StopJobs`
- **params:** X-UIPATH-OrganizationUnitId (header)
- **body:** StopJobsRequest { strategy:string, jobIds:[integer], batchExecutionKey:string }

## GET `/odata/Releases`
Gets multiple releases.
`operationId: Releases_Get`
- **params:** mandatoryPermissions (query), atLeastOnePermissions (query), $select (query), $expand (query), $filter (query), $orderby (query), $top (query), $skip (query), $count (query), X-UIPATH-OrganizationUnitId (header)
- **returns:** ODataValueOfIEnumerableOfReleaseDto { value:[ReleaseDto] }

## GET `/odata/Releases({key})`
Gets a release by id.
`operationId: Releases_GetById`
- **params:** key* (path), $select (query), $expand (query), X-UIPATH-OrganizationUnitId (header)
- **returns:** ReleaseDto { Key:string, ProcessKey:string, ProcessVersion:string, IsLatestVersion:boolean, IsProcessDeleted:boolean, Description:string, Name:string, EntryPointId:integer, EntryPointPath:string, EntryPoint:EntryPointDto, InputArguments:string, EnvironmentVariables:string… }

## GET `/odata/ProcessSchedules`
Gets the process schedules.
`operationId: ProcessSchedules_Get`
- **params:** $select (query), $expand (query), $filter (query), $orderby (query), $top (query), $skip (query), $count (query), X-UIPATH-OrganizationUnitId (header)
- **returns:** ODataValueOfIEnumerableOfProcessScheduleDto { value:[ProcessScheduleDto] }
