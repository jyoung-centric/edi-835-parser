# Orchestrator API — queues-transactions

_Distilled from UiPath Orchestrator API v20.0. All calls need the Bearer token; folder-scoped calls also need the `X-UIPATH-OrganizationUnitId` header (see SKILL.md)._


## POST `/odata/Queues/UiPathODataSvc.AddQueueItem`
Adds a new queue item
`operationId: Queues_AddQueueItem`
- **params:** $select (query), $expand (query), X-UIPATH-OrganizationUnitId (header)
- **body:** AddQueueItemRequest { itemData:QueueItemDataDto }
- **returns:** QueueItemDto { QueueDefinitionId:integer, QueueDefinition:QueueDefinitionDto, ProcessingException:ProcessingExceptionDto, Error:QueueItemErrorDto, Encrypted:boolean, SpecificContent:object, Output:object, OutputData:string, Analytics:object, AnalyticsData:string, Status:string, ReviewStatus:string… }

## POST `/odata/Queues/UiPathODataSvc.BulkAddQueueItems`
Bulk adds queue items
`operationId: Queues_BulkAddQueueItems`
- **params:** $select (query), $expand (query), X-UIPATH-OrganizationUnitId (header)
- **body:** BulkAddQueueItemsRequest { queueName:string, commitType:string, queueItems:[QueueItemDataDto] }
- **returns:** BulkOperationResponseDtoOfFailedQueueItemDto { Success:boolean, Message:string, FailedItems:[FailedQueueItemDto] }

## POST `/odata/Queues/UiPathODataSvc.StartTransaction`
Starts a transaction
`operationId: Queues_StartTransaction`
- **params:** $select (query), $expand (query), X-UIPATH-OrganizationUnitId (header)
- **body:** QueuesStartTransactionRequest { transactionData:TransactionDataDto }
- **returns:** QueueItemDto { QueueDefinitionId:integer, QueueDefinition:QueueDefinitionDto, ProcessingException:ProcessingExceptionDto, Error:QueueItemErrorDto, Encrypted:boolean, SpecificContent:object, Output:object, OutputData:string, Analytics:object, AnalyticsData:string, Status:string, ReviewStatus:string… }

## POST `/odata/Queues({key})/UiPathODataSvc.SetTransactionResult`
Sets the result of a transaction.
`operationId: Queues_SetTransactionResultById`
- **params:** key* (path), X-UIPATH-OrganizationUnitId (header)
- **body:** QueueSetTransactionResultRequest { transactionResult:TransactionResultDto }

## POST `/odata/QueueItems({key})/UiPathODataSvc.SetTransactionProgress`
Updates the progress field of a queue item with the status 'In Progress'.
`operationId: QueueItems_SetTransactionProgressById`
- **params:** key* (path), X-UIPATH-OrganizationUnitId (header)
- **body:** QueueSetTransactionProgressRequest { progress:string }

## GET `/odata/QueueItems`
Gets a collection of queue items.
`operationId: QueueItems_Get`
- **params:** mandatoryPermissions (query), atLeastOnePermissions (query), $select (query), $expand (query), $filter (query), $orderby (query), $top (query), $skip (query), $count (query), X-UIPATH-OrganizationUnitId (header)
- **returns:** ODataValueOfIEnumerableOfQueueItemDto { value:[QueueItemDto] }

## GET `/odata/QueueItems({key})`
Gets a queue item by Id.
`operationId: QueueItems_GetById`
- **params:** key* (path), $select (query), $expand (query), X-UIPATH-OrganizationUnitId (header)
- **returns:** QueueItemDto { QueueDefinitionId:integer, QueueDefinition:QueueDefinitionDto, ProcessingException:ProcessingExceptionDto, Error:QueueItemErrorDto, Encrypted:boolean, SpecificContent:object, Output:object, OutputData:string, Analytics:object, AnalyticsData:string, Status:string, ReviewStatus:string… }

## DELETE `/odata/QueueItems({key})`
Deletes a queue item by Id.
`operationId: QueueItems_DeleteById`
- **params:** key* (path), X-UIPATH-OrganizationUnitId (header)

## POST `/odata/QueueItemComments`
Creates a QueueItemComment.
`operationId: QueueItemComments_Post`
- **params:** X-UIPATH-OrganizationUnitId (header)
- **body:** QueueItemCommentDto { Text:string, QueueItemId:integer, CreationTime:string, UserId:integer, UserName:string, Id:integer }
- **returns:** QueueItemCommentDto { Text:string, QueueItemId:integer, CreationTime:string, UserId:integer, UserName:string, Id:integer }

## GET `/odata/QueueDefinitions`
Gets the list of queue definitions.
`operationId: QueueDefinitions_Get`
- **params:** mandatoryPermissions (query), atLeastOnePermissions (query), $select (query), $expand (query), $filter (query), $orderby (query), $top (query), $skip (query), $count (query), X-UIPATH-OrganizationUnitId (header)
- **returns:** ODataValueOfIEnumerableOfQueueDefinitionDto { value:[QueueDefinitionDto] }

## POST `/odata/QueueDefinitions`
Creates a new queue.
`operationId: QueueDefinitions_Post`
- **params:** X-UIPATH-OrganizationUnitId (header)
- **body:** QueueDefinitionDto { Key:string, Name:string, Description:string, MaxNumberOfRetries:integer, AcceptAutomaticallyRetry:boolean, RetryAbandonedItems:boolean, EnforceUniqueReference:boolean, Encrypted:boolean, SpecificDataJsonSchema:string, OutputDataJsonSchema:string, AnalyticsDataJsonSchema:string, CreationTime:string… }
- **returns:** QueueDefinitionDto { Key:string, Name:string, Description:string, MaxNumberOfRetries:integer, AcceptAutomaticallyRetry:boolean, RetryAbandonedItems:boolean, EnforceUniqueReference:boolean, Encrypted:boolean, SpecificDataJsonSchema:string, OutputDataJsonSchema:string, AnalyticsDataJsonSchema:string, CreationTime:string… }
