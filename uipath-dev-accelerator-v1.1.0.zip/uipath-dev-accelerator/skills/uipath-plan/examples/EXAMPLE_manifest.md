# Plan Manifest — WORKED EXAMPLE (grounded in Orl_HC360_FeeSchedule_Performer)

> Demonstrates the Plan-phase output for a representative story. The grounding is
> real — every reused workflow, selector, and config key below comes from
> `project_index.py` run against the actual performer. Story is illustrative.

## Story
- **Role:** fee-schedule analyst
- **Want:** the bot to update the *Book At (Net)* amount for each charge code on a
  contract, from a worklist spreadsheet
- **So that:** HC360 pricing reflects the latest fee schedule
- **Acceptance criteria:**
  - Given a queued contract item, when its worklist has new Book-At-Net values,
    then each charge code's amount is updated and saved.
  - When a charge code is missing from the contract, then it is logged, not failed.

## Project (auto-detected)
`Orl_HC360_FeeSchedule_Performer` — REFramework ✓ · Object Repository ✓ · app `jp2launcher.exe` (HomeCare 360°)

## Decomposition — REUSE vs NEW

| Step | Action | Artifact (existing file) | Grounded screen / selectors |
|---|---|---|---|
| Launch + log in | ♻️ **reuse** | `HCN_Login.xaml` (args=2) | `*HomeCare*360*Login*` → `HcnMigTextField`, `HcnPasswordField`, `Submit` |
| Go to List Maintenance | ♻️ reuse | `NavigateListMaintenance.xaml` | `HomeCare 360°` frame → `HcnEntryPointButton name='btnListMaint'` |
| Search the contract | ♻️ reuse | `HCN_SearchContracts.xaml` | `List Maintenance*` → `HcnTextField name='Code:'`, `Select` |
| Read charge-code grid | ♻️ reuse | `ReadChargeCodeGrid.xaml` | `Contract*` dialog → `HcnTable [table]` |
| Click a charge-code row | ♻️ reuse | `ClickChargeCodeRow.xaml` (args=2) | dynamic `[strChargeCodeSelector]` ⚠️ |
| Compare current vs new amount | ♻️ reuse | `BookAtNetAmountComparison.xaml` (args=4) | `name='Book At (Net) :'` field |
| Write new amount | ♻️ reuse | `UpdateBookAtNetAmount.xaml` (args=3) | `Contract*` → Book-At-Net text + `Save` |
| Save | ♻️ reuse | `SaveDataAfterChargeGridUpdated.xaml` | `Contract*` → `Save [push button]` |
| **Orchestrate the per-charge-code loop over the worklist** | 🆕 **NEW** | `ProcessContractWorklist.xaml` | (no UI — pure orchestration) |
| Log missing charge code (AC #2) | 🆕 NEW (small) | inside the new workflow | — |

**Net new surface: ONE orchestration workflow.** The story is ~90% existing pieces;
the plan's job was to find that and name the 10%.

### New artifact spec → hand to uipath-author
```yaml
- name: ProcessContractWorklist
  kind: workflow ; action: new ; file: DataFiles/ProcessContractWorklist.xaml
  args:
    - { name: in_dtWorklist,    direction: In,    type: sd:DataTable }
    - { name: in_strContractCode, direction: In,  type: x:String }
    - { name: io_TransactionItem, direction: InOut, type: ui:QueueItem }
  steps:
    - For each worklist row → ClickChargeCodeRow → BookAtNetAmountComparison
    - If changed → UpdateBookAtNetAmount → SaveDataAfterChargeGridUpdated
    - If row not found in grid → LogMessage (Warn), continue   # AC #2
  invokes: [ClickChargeCodeRow, BookAtNetAmountComparison, UpdateBookAtNetAmount,
            SaveDataAfterChargeGridUpdated]
```

## Invocation graph
```
Main → Framework/Process.xaml (per queue item)
        → HCN_Login → NavigateListMaintenance → HCN_SearchContracts
        → ReadChargeCodeGrid
        → ProcessContractWorklist (NEW)
              ↳ ClickChargeCodeRow → BookAtNetAmountComparison
              ↳ UpdateBookAtNetAmount → SaveDataAfterChargeGridUpdated
```

## GAPS & DISCOURSE — must resolve before generation
1. **Duplicate login workflow.** Index shows `HCN_Login.xaml` (2 args) AND
   `HCN_Login1.xaml` (class `HCN_Login`, 3 args). *Which is canonical?*
2. **Class/file mismatch.** `ReadChargeCodeGrid.xaml` and `DeleteChargeCode.xaml`
   both define class `IterateChargeCodeOverPricingGrid`. Reusing "read the grid" —
   *confirm `ReadChargeCodeGrid.xaml` is the intended one.*
3. **Dynamic selector.** `ClickChargeCodeRow` targets a runtime-built
   `[strChargeCodeSelector]`. *Confirm the worklist supplies the value that
   selector is built from (charge code), else the row click won't resolve.*
4. **Config key.** Worklist source path — reuse `SharedDriveOutputPath`, or is the
   worklist read from the `OrchestratorQueueName_ContractFileDetails` payload?
5. **AC #2 severity.** "Missing charge code → log, not fail" — log as Business
   Exception (queue item Failed-Business) or Warn-and-continue within the item?
```
```
