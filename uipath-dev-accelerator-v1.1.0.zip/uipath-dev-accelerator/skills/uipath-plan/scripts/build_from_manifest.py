#!/usr/bin/env python3
"""
build_from_manifest.py — the uipath-plan → uipath-author hand-off.

Consumes an APPROVED, machine-readable Plan Manifest (JSON) and drives
uipath-author's new_workflow.py to generate a valid, Studio-openable scaffold for
each NEW workflow artifact — pre-wired with:
  * the planned arguments,
  * an InvokeWorkflowFile stub for each workflow it `invokes` (deterministic from
    the plan), and
  * Log start/end + the planned steps as annotations/comments,
then validates every generated file. REUSE/MODIFY artifacts are reported, not
regenerated (never overwrite existing work).

This closes the loop: story → plan → (approved) → generated scaffolds. The
detailed activity logic inside each stub is then filled in (by Claude using the
uipath-author fragments, or by a developer).

Usage:
    build_from_manifest.py manifest.json --project /path/to/uipath/project
    build_from_manifest.py manifest.json --project . --dry-run

Manifest schema: see ../examples/manifest.schema.json and EXAMPLE_manifest.json.
"""
import argparse, json, os, subprocess, sys
from xml.sax.saxutils import escape

HERE = os.path.dirname(os.path.abspath(__file__))
AUTHOR = os.path.normpath(os.path.join(HERE, "..", "..", "uipath-author", "scripts"))
NEW_WF = os.path.join(AUTHOR, "new_workflow.py")
VALIDATE = os.path.join(AUTHOR, "validate_xaml.py")

def invoke_stub(target, arg_map):
    """Build an InvokeWorkflowFile activity XAML from a plan `invokes` entry."""
    fn = target if target.endswith(".xaml") else f"Frameworks\\{target}.xaml"
    lines = [f'    <ui:InvokeWorkflowFile DisplayName="Invoke {escape(os.path.basename(target))}" '
             f'WorkflowFileName="{escape(fn)}">']
    if arg_map:
        lines.append("      <ui:InvokeWorkflowFile.Arguments>")
        for k, spec in arg_map.items():
            typ = spec.get("type", "x:String")
            direction = spec.get("direction", "In") + "Argument"
            expr = escape(spec.get("expr", k))
            lines.append(f'        <{direction} x:TypeArguments="{typ}" '
                         f'x:Key="{escape(k)}">[{expr}]</{direction}>')
        lines.append("      </ui:InvokeWorkflowFile.Arguments>")
    lines.append("    </ui:InvokeWorkflowFile>")
    return "\n".join(lines)

def build_body(artifact):
    name = artifact["name"]
    parts = [f'    <ui:LogMessage DisplayName="Log Message - Started" Level="Info" '
             f'Message="[&quot;{escape(name)} started&quot;]" />']
    for step in artifact.get("steps", []):
        parts.append(f'    <ui:Comment DisplayName="TODO" Text="{escape(step)}" />')
    for inv in artifact.get("invokes", []):
        if isinstance(inv, str):
            parts.append(invoke_stub(inv, {}))
        else:
            parts.append(invoke_stub(inv["target"], inv.get("args", {})))
    parts.append(f'    <ui:LogMessage DisplayName="Log Message - Completed" Level="Info" '
                 f'Message="[&quot;{escape(name)} completed&quot;]" />')
    return "\n".join(parts)

def gen_workflow(artifact, project, project_json, dry):
    name = artifact["name"]
    rel = artifact.get("file", f"Frameworks/{name}.xaml")
    out = os.path.join(project, rel)
    body = build_body(artifact)
    body_file = out + ".body.tmp"
    if not dry:
        os.makedirs(os.path.dirname(out), exist_ok=True)
        open(body_file, "w").write(body)
    cmd = [sys.executable, NEW_WF, "--name", name, "--out", out,
           "--project-json", project_json, "--body-file", body_file]
    for arg in artifact.get("args", []):
        cmd += ["--arg", f"{arg['name']}:{arg['direction']}:{arg['type']}"]
    if dry:
        return ("DRY", rel, "would generate: " + " ".join(
            a['name'] for a in artifact.get('args', [])) or "(no args)")
    r = subprocess.run(cmd, capture_output=True, text=True)
    if os.path.exists(body_file):
        os.remove(body_file)
    if r.returncode != 0:
        return ("FAIL", rel, r.stderr.strip() or r.stdout.strip())
    v = subprocess.run([sys.executable, VALIDATE, out], capture_output=True, text=True)
    ok = "OK" if v.returncode == 0 else "INVALID"
    return (ok, rel, v.stdout.strip())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("manifest")
    ap.add_argument("--project", required=True, help="target UiPath project dir")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    man = json.load(open(a.manifest))
    project = os.path.abspath(a.project)
    project_json = os.path.join(project, "project.json")
    if not os.path.exists(project_json):
        print(f"!! no project.json at {project_json} — custom (p:) types won't "
              f"resolve. Continue with a bare scaffold.", file=sys.stderr)
        project_json = os.devnull

    print(f"Plan Manifest: {man.get('story', {}).get('want', man.get('name','?'))}")
    print(f"Target project: {project}\n")
    results = {"new": [], "reuse": [], "modify": [], "gaps": man.get("gaps", [])}
    for art in man.get("artifacts", []):
        action = art.get("action", "new")
        kind = art.get("kind", "workflow")
        if kind != "workflow":
            results.setdefault(action, []).append((kind, art["name"], "(non-workflow artifact)"))
            continue
        if action == "reuse":
            results["reuse"].append(("OK", art.get("file", art["name"]), "reused as-is"))
        elif action == "modify":
            results["modify"].append(("MANUAL", art.get("file", art["name"]),
                                      "existing — edit by hand / with uipath-author"))
        else:
            results["new"].append(gen_workflow(art, project, project_json, a.dry_run))

    for group in ("new", "modify", "reuse"):
        rows = results.get(group, [])
        if not rows:
            continue
        print(f"── {group.upper()} ──")
        for status, path, note in rows:
            print(f"  [{status:7s}] {path}   {note}")
        print()
    if results["gaps"]:
        print("── UNRESOLVED GAPS (should have been closed in discourse) ──")
        for g in results["gaps"]:
            print(f"  ⚠ {g}")

    bad = [r for r in results["new"] if r[0] not in ("OK", "DRY")]
    sys.exit(1 if bad else 0)

if __name__ == "__main__":
    main()
