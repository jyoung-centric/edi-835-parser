#!/usr/bin/env python3
"""
project_index.py — auto-detect a UiPath project and emit a GROUNDING INDEX.

This is the knowledge base the Plan phase decomposes a user story against, so
the planner references REAL artifacts (screens, selectors, existing workflows,
config keys) instead of hallucinating them. Works on any UiPath project dir;
degrades gracefully (greenfield → empty sections → planner uses placeholders).

Emits JSON to stdout:
{
  "project": {name, description, type, refr amework, has_object_repo, dependencies[]},
  "workflows": [{file, class, args:[{name,direction,type}]}],
  "config_keys": [str],            # keys read via Config(...)/in_Config(...)
  "applications": [str],           # app='...' targets in selectors
  "screens": [{app, window_cls, title, elements:[{desc, files:[...]}]}],
  "dynamic_selectors": [{expr, file}]   # runtime-built selectors to verify
}
"""
import json, os, re, sys, glob, collections

SEL_RE  = re.compile(r'(?:Selector|FullSelector|FuzzySelector)="([^"]*)"')
PROP_RE = re.compile(r'<x:Property\s+Name="([^"]+)"\s+Type="([^"]+)"')
CFG_RE  = re.compile(r'\b(?:in_)?Config\(&quot;([^&]+)&quot;\)')
DIR_RE  = re.compile(r'(InArgument|OutArgument|InOutArgument)\((.+)\)$')

def un(s):
    for a, b in [('&quot;', '"'), ('&gt;', '>'), ('&lt;', '<'),
                 ('&amp;', '&'), ('&#xA;', ''), ('&#xD;', '')]:
        s = s.replace(a, b)
    return s.strip()

def window_of(raw):
    w = re.search(r"<wnd\b[^>]*>", raw)
    if not w: return None
    c = re.search(r"cls='([^']*)'", w.group(0))
    t = re.search(r"title='([^']*)'", w.group(0))
    a = re.search(r"app='([^']*)'", raw)
    return (a.group(1) if a else '', c.group(1) if c else '', t.group(1) if t else '')

def leaf(raw):
    nodes = re.findall(r'<[^>]+>', raw)
    n = nodes[-1] if nodes else raw
    cls = re.search(r"cls='([^']*)'", n); nm = re.search(r"name='([^']*)'", n)
    role = re.search(r"role='([^']*)'", n)
    parts = []
    if cls: parts.append(f"cls={cls.group(1)}")
    if nm:  parts.append(f"name='{nm.group(1)}'")
    if role: parts.append(f"[{role.group(1)}]")
    return ' '.join(parts) or n[:60]

def parse_direction(typ):
    m = DIR_RE.match(typ)
    return (m.group(1).replace('Argument', ''), m.group(2)) if m else ('', typ)

def main(root):
    root = os.path.abspath(root)
    idx = {"project": {}, "workflows": [], "config_keys": set(),
           "applications": set(), "screens": [], "dynamic_selectors": []}

    # ---- project.json ----
    pj_path = os.path.join(root, "project.json")
    if os.path.exists(pj_path):
        pj = json.load(open(pj_path))
        idx["project"] = {
            "name": pj.get("name"), "description": pj.get("description"),
            "type": pj.get("designOptions", {}).get("outputType"),
            "dependencies": sorted(pj.get("dependencies", {}).keys()),
        }
    fw = os.path.join(root, "Framework")
    idx["project"]["reframework"] = os.path.isdir(fw) and os.path.exists(
        os.path.join(fw, "Process.xaml"))
    idx["project"]["has_object_repo"] = os.path.isdir(os.path.join(root, ".objects"))

    # ---- per-file scan ----
    screen_map = collections.defaultdict(lambda: collections.defaultdict(set))
    for f in sorted(glob.glob(os.path.join(root, "**/*.xaml"), recursive=True)):
        rel = os.path.relpath(f, root)
        base = os.path.basename(f)
        try: txt = open(f, encoding='utf-8').read()
        except Exception: continue

        # workflow class + arguments
        cls_m = re.search(r'x:Class="([^"]+)"', txt)
        args = []
        # only the root <x:Members> block (first one)
        mem = re.search(r'<x:Members>(.*?)</x:Members>', txt, re.S)
        if mem:
            for nm, typ in PROP_RE.findall(mem.group(1)):
                d, t = parse_direction(typ)
                args.append({"name": nm, "direction": d, "type": t})
        if cls_m:
            idx["workflows"].append({"file": rel, "class": cls_m.group(1), "args": args})

        # config keys
        for k in CFG_RE.findall(txt):
            idx["config_keys"].add(k)

        # selectors → screens
        for m in SEL_RE.finditer(txt):
            raw = un(m.group(1))
            if not raw: continue
            if raw.startswith('[') or raw == '{x:Null}':
                if raw.startswith('['):
                    idx["dynamic_selectors"].append({"expr": raw, "file": base})
                continue
            w = window_of(raw)
            if w:
                idx["applications"].add(w[0] or 'jp2launcher.exe')
                screen_map[(w[0], w[1], w[2])][leaf(raw)].add(base)
            else:
                screen_map[('', '(relative)', '')][leaf(raw)].add(base)

    for (app, wcls, ttl), elems in screen_map.items():
        idx["screens"].append({
            "app": app or 'jp2launcher.exe', "window_cls": wcls, "title": ttl,
            "elements": [{"desc": d, "files": sorted(fs)} for d, fs in sorted(elems.items())],
        })
    idx["screens"].sort(key=lambda s: -sum(len(e["files"]) for e in s["elements"]))
    idx["config_keys"] = sorted(idx["config_keys"])
    idx["applications"] = sorted(idx["applications"])
    json.dump(idx, sys.stdout, indent=2)
    print()

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else ".")
