#!/usr/bin/env python3
"""
verify_grounding.py — the uipath-plan → uipath-orchestrator-api cross-wire.

The Plan phase's static index (project_index.py) tells us which Orchestrator
ASSET names a story will depend on (config keys read in InitAllSettings) and
which QUEUES the robot touches. This bridge turns those from "names the planner
hopes exist" into CONFIRMED FACTS by resolving them live against the tenant:

  config key ──▶ Assets lookup ──▶ value ──▶ (if queue-ish) QueueDefinitions check

Output is a grounding-verification report the planner folds into the Plan
Manifest: `confirmed[]` (exists, with value) vs `gaps[]` (missing → discourse
question). Degrades gracefully: with no creds / no network it runs OFFLINE and
emits the exact list of names a human must confirm — still useful for discourse.

Usage:
    verify_grounding.py --index index.json [--folder 123]
    # creds via env (see uipath-orchestrator-api/SKILL.md):
    #   UIPATH_CLIENT_ID UIPATH_CLIENT_SECRET UIPATH_BASE_URL [UIPATH_FOLDER_ID]
"""
import argparse, json, os, sys

# --- locate the sibling orchestrator-api client (importable module) ---
def _load_orch_client():
    cand = [os.environ.get("UIPATH_ORCH_SCRIPTS"),
            os.path.join(os.path.dirname(__file__),
                         "..", "..", "uipath-orchestrator-api", "scripts")]
    for c in cand:
        if c and os.path.isfile(os.path.join(c, "orch_call.py")):
            sys.path.insert(0, os.path.abspath(c))
            import orch_call            # noqa: E402
            return orch_call
    return None

def classify(key):
    k = key.lower()
    if "queue" in k and ("name" in k or "queuename" in k): return "queue-name-asset"
    if "queue" in k and "folder" in k:                     return "folder-asset"
    if "credential" in k:                                  return "credential-asset"
    if any(x in k for x in ("path", "url", "argument", "site")): return "config-asset"
    if k.startswith("logmessage") or k.startswith("exceptionmessage"): return "local-text"
    return "asset"

def _names(resp_text):
    try: data = json.loads(resp_text)
    except Exception: return {}
    out = {}
    for v in data.get("value", []):
        nm = v.get("Name")
        if nm is not None:
            out[nm] = v.get("StringValue") or v.get("Value") or v.get("IntValue")
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--index", required=True)
    ap.add_argument("--folder", help="X-UIPATH-OrganizationUnitId")
    a = ap.parse_args()

    idx = json.load(open(a.index))
    keys = [k for k in idx.get("config_keys", [])
            if classify(k) != "local-text"]
    # explicit queue names a story references, if the index recorded any
    queue_refs = sorted({q for q in idx.get("queue_names", [])})

    report = {"verification": "offline", "folder": a.folder,
              "checked": {"assets": len(keys), "queues": len(queue_refs)},
              "confirmed": [], "gaps": [], "unverified": []}

    orch = _load_orch_client()
    live = False
    assets, queues = {}, set()
    if orch and os.environ.get("UIPATH_CLIENT_ID") and os.environ.get("UIPATH_BASE_URL"):
        try:
            folder = a.folder or os.environ.get("UIPATH_FOLDER_ID")
            s1, t1 = orch.call("GET", "/odata/Assets?$top=1000", folder=folder)
            s2, t2 = orch.call("GET", "/odata/QueueDefinitions?$top=1000", folder=folder)
            if s1 == 200 and s2 == 200:
                assets = _names(t1)
                queues = set(_names(t2).keys())
                live = True
                report["verification"] = "live"
            else:
                report["error"] = f"Assets HTTP {s1}, Queues HTTP {s2}"
        except Exception as e:
            report["error"] = f"{type(e).__name__}: {e}"

    for key in keys:
        kind = classify(key)
        if not live:
            report["unverified"].append({"name": key, "kind": kind,
                "check": "asset exists" if "asset" in kind else "exists"})
            continue
        if key in assets:
            entry = {"name": key, "kind": kind, "value": assets[key]}
            # two-hop: queue-name asset → its value must be a defined queue
            if kind == "queue-name-asset" and assets[key]:
                if assets[key] in queues:
                    entry["queue_exists"] = True
                else:
                    entry["queue_exists"] = False
                    report["gaps"].append(
                        f"Asset '{key}' = '{assets[key]}' but no queue by that "
                        f"name exists in folder {report['folder']}")
            report["confirmed"].append(entry)
        else:
            report["gaps"].append(f"Asset '{key}' not found in folder "
                                  f"{report['folder']} (kind: {kind})")

    if live:
        for q in queue_refs:
            (report["confirmed"] if q in queues else report["gaps"]).append(
                {"queue": q, "exists": q in queues} if q in queues
                else f"Queue '{q}' referenced by story not defined in Orchestrator")

    json.dump(report, sys.stdout, indent=2)
    print()
    # human hint
    if not live:
        sys.stderr.write(
            "\n[offline] No live verification — set UIPATH_CLIENT_ID / "
            "UIPATH_CLIENT_SECRET / UIPATH_BASE_URL to confirm against the tenant.\n"
            "The 'unverified' list is what the planner must ask the user to confirm.\n")

if __name__ == "__main__":
    main()
