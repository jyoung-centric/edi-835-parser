---
name: uipath-plan
description: >
  Turn a UiPath user story into an agreed, grounded build plan BEFORE any XAML is
  generated. Use when the user provides a user story / requirement / acceptance
  criteria and wants it implemented as UiPath automation. Auto-detects the target
  project, decomposes the story into expected artifacts (workflows, data models,
  config, selectors), grounds every UI step against real screens/selectors (never
  invented), surfaces gaps and ambiguities for discussion, and produces a Plan
  Manifest the user approves. Hands the approved manifest to uipath-author.
---

# uipath-plan

The front door of UiPath authoring. A user story states *business intent*, not UI
mechanics or file structure. This skill decomposes it into concrete artifacts
**in dialogue with the user**, grounded in what the project actually contains, and
produces an approved Plan Manifest. It does NOT generate XAML — that's uipath-author.

## Core rule

**Never fabricate a selector, workflow, or config key.** Ground every step against
the project index. If the story needs something that does not exist, list it as a
GAP for the user to decide on — never silently invent it.

## Workflow

1. **Index the project (auto-detect grounding).**
   ```bash
   python3 scripts/project_index.py /path/to/uipath/project > index.json
   ```
   Yields: project type (REFramework?), existing workflows + their typed args,
   config keys, applications, screens→elements (real selectors), and dynamic
   (runtime-built) selectors to verify. Greenfield project → mostly-empty index;
   the planner then proposes placeholders instead of references.

1b. **Verify grounding against live Orchestrator (cross-wire — optional but
   recommended).** The static index tells you which Asset names (config keys) and
   queues a story depends on; this step confirms they actually exist in the tenant
   rather than assuming:
   ```bash
   # creds via env — see ../uipath-orchestrator-api/SKILL.md
   python3 scripts/verify_grounding.py --index index.json --folder <id> > grounding.json
   ```
   It resolves `config key → Asset → value → (if a queue name) QueueDefinitions`,
   emitting `confirmed[]` (with values) vs `gaps[]`. This turns "config key gap"
   discourse items from guesses into **facts** — and catches real bugs (a missing
   asset, or an asset whose value names a queue that doesn't exist) at plan time.
   With no creds it runs OFFLINE and returns the exact names for the user to
   confirm — still feeds the discourse. Bridge: `verify_grounding.py` imports the
   sibling `uipath-orchestrator-api` client (override its path with
   `UIPATH_ORCH_SCRIPTS`).

2. **Parse the story.** Extract role / want / so-that and any acceptance criteria
   (Given-When-Then → verification artifacts). Identify the business steps.

3. **Decompose into expected artifacts.** For each step decide REUSE (an existing
   workflow in the index) vs. NEW (must be created) vs. MODIFY. Map UI steps to
   real screens/selectors from the index. Identify needed data models, config
   keys, and queue/transaction touchpoints. Build the invocation graph.

4. **Surface gaps & ambiguities (DISCOURSE).** Present, and ask the user about:
   - UI steps with no grounding selector (must be recorded in Object Repository).
   - **Live-grounding gaps from step 1b** — missing Orchestrator assets, or an
     asset whose value names a non-existent queue (confirmed facts, not guesses).
   - Ambiguous intent (which screen/field the story means).
   - Index anomalies relevant to the story (duplicate/renamed workflows,
     class/file mismatches, dynamic selectors).
   - Output unit choice when genuinely open (one workflow vs. a transaction).
   Iterate until resolved. Use AskUserQuestion for discrete forks.

5. **Emit the Plan Manifest** (see schema below) and get explicit approval.

6. **Hand off** the approved manifest to uipath-author for generation + validation.
   Emit the machine-readable manifest (`examples/manifest.schema.json`) and run:
   ```bash
   python3 scripts/build_from_manifest.py manifest.json --project /path/to/project
   ```
   This generates a valid, Studio-openable scaffold for each `action:new` workflow
   — pre-wired with the planned arguments and an `InvokeWorkflowFile` stub per
   `invokes` entry, steps as TODO comments — then validates each. `reuse`/`modify`
   artifacts are reported, never overwritten. Use `--dry-run` to preview. The
   detailed activity logic inside each stub is then filled in with uipath-author's
   fragments. `examples/EXAMPLE_manifest.json` is a complete worked input.

## Plan Manifest schema

```yaml
story:        { role, want, so_that, acceptance_criteria[] }
project:      { name, reframework, has_object_repo }     # from index
artifacts:
  - name:     UpdateBookAtNetAmount
    kind:     workflow | data_model | config | test
    action:   reuse | new | modify
    file:     DataFiles/UpdateBookAtNetAmount.xaml
    args:     [{name, direction, type}]                  # for new/modify
    screen:   { app, window_cls, title }                 # for UI workflows
    selectors:[ "<grounded selector desc>" ]             # from index only
    steps:    [ "natural-language step" ]
invocation:   "Main → Process → (HCN_Login, NavigateListMaintenance, …)"
gaps:         [ "missing selector / unknown to resolve" ]
questions:    [ "discourse items answered before generation" ]
```

## Files

- `scripts/project_index.py` — auto-detect grounding indexer. Run first.
- (uses) `../uipath-author/` — receives the approved manifest for generation.

## Acceleration principle

The index usually shows a story is 70–90% existing pieces. The plan's value is
naming the *small* genuinely-new surface and wiring, not regenerating what's there.
