---
name: uipath-init
description: >
  Initialize a project-tailored CLAUDE.md for a UiPath project. Use when starting
  work in a UiPath project that has no CLAUDE.md, when the user asks to init /
  onboard / document a UiPath project for Claude, or right after installing the
  UiPath Dev Accelerator. Inspects the project (type, workflows, config/assets,
  UI selectors) and writes a concise CLAUDE.md that grounds future sessions and
  points to the accelerator skills.

---

# uipath-init

Generates a `CLAUDE.md` tailored to a specific UiPath project so every future
Claude Code session in that project starts grounded — knowing its type
(REFramework?), structure, key workflows and their argument contracts, config
keys / Orchestrator assets, UI applications and selector surface, and which
accelerator skills to use with what guardrails.

## When to use

- A UiPath project has no `CLAUDE.md` and you're about to work in it.
- The user says "init / set up / onboard / document this UiPath project."
- Immediately after installing the accelerator (see `INSTALL_FOR_CLAUDE.md`).

## Usage

```bash
python3 scripts/init_claude_md.py /path/to/UiPathProject          # writes <project>/CLAUDE.md
python3 scripts/init_claude_md.py .                               # current dir
python3 scripts/init_claude_md.py /path/to/project --force        # overwrite existing
python3 scripts/init_claude_md.py /path/to/project --out DOC.md   # write elsewhere
```

It refuses to overwrite an existing `CLAUDE.md` unless `--force` (so you never
clobber a hand-written one by accident).

## What it produces

A `CLAUDE.md` with: Overview (type, deps, workflow count), Structure, Key
workflows (with argument contracts), Config keys / Orchestrator assets, and — for
UI-automation projects — Applications & selectors, plus a "Working in this
project" section and Guardrails (never fabricate selectors/config; validate
generated XAML; prefer reuse; REFramework layering).

## How it works

Reuses the accelerator's own tools: it runs the sibling `uipath-plan`
`project_index.py` for the project index and `uipath-selectors`
`extract_selectors.py` for the UI surface, then composes the doc. If those
siblings aren't reachable it falls back to a minimal `project.json`-only summary.
Pure static analysis — no UiPath install, network, or credentials.

## After generating

**Review and edit** the CLAUDE.md — it's a strong first draft, not gospel. Add
project-specific business context the static analysis can't know (SLAs, quirks,
who owns what), then commit it with the project.
