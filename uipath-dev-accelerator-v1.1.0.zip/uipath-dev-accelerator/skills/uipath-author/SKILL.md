---
name: uipath-author
description: >
  Author UiPath Studio workflows (.xaml) fast and correctly. Use when the user
  wants to create, scaffold, or add a new UiPath workflow, Framework, activity,
  or invokable .xaml — or when generating/editing UiPath XAML by hand. Produces
  Studio-openable files by emitting the deterministic scaffold mechanically and
  composing the activity tree from vetted snippets. Portable across any UiPath
  Windows-target project via its project.json.
---

# uipath-author

Generate valid, Studio-openable UiPath `.xaml` workflows without hand-writing the
verbose XAML boilerplate. The skill splits every workflow into:

- **~85% deterministic scaffold** — root element, namespace block, the two
  `TextExpression` lists, `x:Members`. Emitted by `scripts/new_workflow.py`.
  Never authored by hand; never hallucinated.
- **~15% activity tree** — the actual logic. Composed from `reference/fragments.xaml`,
  following `reference/expression-syntax.md`, then validated.

## When to use

Creating/scaffolding a new UiPath workflow, Framework, or invokable .xaml;
adding activities to a generated body; or producing UiPath XAML programmatically.
Not for *reading* existing workflows (that's a separate reader skill).

## Workflow

1. **Locate the project profile.** Find the project's `project.json` (root of the
   UiPath project). It yields the root namespace, the `.Core` assembly, and the
   dependency-driven assembly refs. Pass it via `--project-json`. Without it, the
   file still generates but custom (`p:`) types won't resolve.

2. **Define the arguments.** Decide the workflow's In/Out/InOut arguments. Follow
   the team convention: `in_*` for inputs, `out_*` for outputs, `io_*` for
   in/out. Each is `name:Direction:Type` where Direction ∈ {In, Out, InOut} and
   Type is e.g. `x:String`, `x:Boolean`, `sd:DataTable`, or `p:CustomModel`.

3. **Author the body** (optional — omit for a Log-start/Log-end skeleton). Write
   the inner activity tree to a file using `reference/fragments.xaml` snippets.
   Replace every `{{PLACEHOLDER}}`. Obey `reference/expression-syntax.md`:
   bracket-wrap expressions, escape `"`→`&quot;`, prefer `MultipleAssign` over
   chained `Assign`, and wrap every Orchestrator/DB/network write in a
   `RetryScope`. Declare any extra prefixes you use (`s:`, `sd:`) — see anatomy.

4. **Generate:**
   ```bash
   python3 scripts/new_workflow.py \
     --name MyWorkflow \
     --project-json /path/to/project.json \
     --arg "in_strInput:In:x:String" \
     --arg "io_Model:InOut:p:MyModel" \
     --body-file body.xaml \
     --out /path/to/Frameworks/MyWorkflow.xaml
   ```

5. **Validate — always:**
   ```bash
   python3 scripts/validate_xaml.py /path/to/Frameworks/MyWorkflow.xaml
   ```
   Must print `OK`. Fix any reported undeclared-prefix or malformed-XML error
   before handing the file back.

6. **Report** what you generated: the file path, its arguments, and the activities
   in the body. Note that Studio will re-layout designer coordinates on first open
   (this is expected — the scaffold omits view-state by design).

## Files

- `scripts/new_workflow.py` — scaffold generator (deterministic). `--help` for args.
- `scripts/validate_xaml.py` — structural validator. Run on every output.
- `reference/xaml-anatomy.md` — mandatory vs. optional structure; prefix cheat-sheet.
- `reference/expression-syntax.md` — VB expression + XML-escaping rules.
- `reference/fragments.xaml` — vetted, view-state-stripped activity snippets.

## Conventions this skill encodes (parameterized, not hardcoded)

- `InvokeWorkflowFile` dispatch: every reusable unit is its own `Frameworks/*.xaml`.
- `RetryScope` (3 retries / 5 s) wraps every Orchestrator queue/transaction write.
- `MultipleAssign` preferred over chains of single `Assign`.
- `in_Config(...)` dictionary for queue names, folder paths, settings.
- Custom data-model types resolve via the `p:` namespace + the project `.Core` ref.

## Limits / known gaps (POT stage)

- Only `Sequence`-rooted workflows are generated; `Flowchart` roots are TODO.
- `DEPENDENCY_REFS` in the generator covers common packages; exotic packages may
  need a ref added there for their types to resolve.
- Structural validation only — no live Studio open-test in this environment.
