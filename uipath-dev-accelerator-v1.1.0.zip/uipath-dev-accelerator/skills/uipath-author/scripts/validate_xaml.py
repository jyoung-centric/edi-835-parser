#!/usr/bin/env python3
"""
validate_xaml.py — structural sanity check for a generated UiPath .xaml before
it is handed back / opened in Studio. Catches the failure modes that make Studio
refuse to open a file.

Checks:
  1. Well-formed XML.
  2. Root is an <Activity> with an x:Class.
  3. Every namespace prefix used on a tag is declared on the root.
  4. Required scaffold blocks are present (NamespacesForImplementation,
     ReferencesForImplementation).
Exit code 0 = OK, 1 = problems (printed).
"""
import re
import sys
import xml.etree.ElementTree as ET


def main(path):
    with open(path) as f:
        text = f.read()

    problems = []

    # 1. Well-formed XML
    try:
        ET.fromstring(text)
    except ET.ParseError as e:
        print(f"FAIL: not well-formed XML: {e}")
        return 1

    # 2. Root Activity + x:Class
    if not re.search(r"<Activity\b", text):
        problems.append("root <Activity> element missing")
    if not re.search(r'x:Class="[^"]+"', text):
        problems.append("x:Class attribute missing on root")

    # 3. Declared prefixes vs used prefixes
    declared = set(re.findall(r'xmlns:([A-Za-z0-9_]+)=', text))
    declared.add("xml")
    used = set(re.findall(r'<([A-Za-z0-9_]+):', text))
    used |= set(re.findall(r'x:TypeArguments="([^"]+)"', text)[0].split(":")[0]
                for _ in [0]) if False else set()
    # prefixes used inside attribute type args, e.g. InOutArgument(p:Foo)
    used |= set(re.findall(r'\(([A-Za-z0-9_]+):', text))
    undeclared = sorted(p for p in used if p not in declared)
    if undeclared:
        problems.append(f"undeclared namespace prefixes: {undeclared}")

    # 4. Required scaffold blocks
    for block in ("NamespacesForImplementation", "ReferencesForImplementation"):
        if block not in text:
            problems.append(f"missing scaffold block: {block}")

    if problems:
        print("FAIL:")
        for p in problems:
            print(f"  - {p}")
        return 1
    print(f"OK: {path} is structurally valid")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
