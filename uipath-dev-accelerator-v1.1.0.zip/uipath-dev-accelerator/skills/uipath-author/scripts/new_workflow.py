#!/usr/bin/env python3
"""
new_workflow.py — generate a valid, Studio-openable UiPath .xaml skeleton.

The deterministic scaffold (root element, namespace block, TextExpression
namespace/reference lists, x:Members) is emitted mechanically so it is never
hallucinated. The activity tree is supplied by the caller (the LLM) as a list
of fragment dicts, or left as a single Log-start / Log-end skeleton.

Portability: project-specific bits (root namespace, Core assembly, extra
dependency assembly refs) come from a project profile derived from project.json.
Everything else is universal UiPath Windows-target boilerplate.

Usage:
    new_workflow.py --name AddOutputNotes --project-json /path/project.json \
        --arg "in_strOutputNotes:In:String" \
        --arg "io_EFTTransactionClaimDataModel:InOut:p:EFT_Transaction_Claim_DataModel" \
        --out AddOutputNotes.xaml
"""
import argparse
import json
import os
import re
import sys
from xml.sax.saxutils import escape

# --- Universal boilerplate (present in every UiPath Windows-target workflow) ---

BASE_NAMESPACES = [
    "System.Activities", "System.Activities.Statements",
    "System.Activities.Expressions", "System.Activities.Validation",
    "System.Activities.XamlIntegration", "Microsoft.VisualBasic",
    "Microsoft.VisualBasic.Activities", "System", "System.Collections",
    "System.Collections.Generic", "System.Collections.ObjectModel",
    "System.Data", "System.Diagnostics", "System.Drawing", "System.IO",
    "System.Linq", "System.Net.Mail", "System.Xml", "System.Xml.Linq",
    "UiPath.Core", "UiPath.Core.Activities", "System.Windows.Markup",
    "GlobalVariablesNamespace", "GlobalConstantsNamespace",
    "System.Linq.Expressions", "System.Runtime.Serialization",
    "System.Reflection",
]

BASE_REFERENCES = [
    "Microsoft.VisualBasic", "mscorlib", "System", "System.Activities",
    "System.ComponentModel.TypeConverter", "System.Core", "System.Data",
    "System.Data.Common", "System.Data.DataSetExtensions", "System.Drawing",
    "System.Drawing.Common", "System.Drawing.Primitives", "System.Linq",
    "System.Net.Mail", "System.ObjectModel", "System.Private.CoreLib",
    "System.Xaml", "System.Xml", "System.Xml.Linq",
    "UiPath.System.Activities", "UiPath.UiAutomation.Activities",
    "UiPath.Studio.Constants", "System.Memory.Data", "System.Console",
    "System.Security.Permissions", "System.Configuration.ConfigurationManager",
    "System.ComponentModel", "System.Memory", "System.Private.Uri",
    "System.Linq.Expressions", "System.Private.ServiceModel",
    "System.Private.DataContractSerialization",
    "System.Runtime.Serialization.Formatters",
    "System.Runtime.Serialization.Primitives",
    "System.Reflection.DispatchProxy", "System.Reflection.TypeExtensions",
    "System.Reflection.Metadata", "System.Collections",
    "System.Collections.NonGeneric",
]

# Dependency package -> extra assembly refs it pulls in (extend as needed).
# NOTE: only include refs Studio actually adds for that package. Spurious extra
# refs are harmless (Studio ignores them) but keep this tight for clean output.
DEPENDENCY_REFS = {
    "UiPath.Excel.Activities": ["UiPath.Excel.Activities.Design", "NPOI.Core"],
    "UiPath.Mail.Activities": [],            # System.Net.Mail already in BASE
    "UiPath.WebAPI.Activities": [],          # UiPath.Web.Activities added on demand
    "UiPath.UIAutomation.Activities": [],    # UiPath.UiAutomation.Activities in BASE
    "UiPath.FTP.Activities": [],
    "UiPath.AmazonWebServices.Activities": [],
}

# Map an arg direction to its XAML wrapper.
DIRECTION = {
    "In": "InArgument", "Out": "OutArgument", "InOut": "InOutArgument",
}

# Known optional prefixes, declared on the root only when the args/body use them.
# (ui/p/x/scg/sco/sap/sap2010/mc are always declared.)
OPTIONAL_XMLNS = {
    "s":   "clr-namespace:System;assembly=System.Private.CoreLib",
    "sd":  "clr-namespace:System.Data;assembly=System.Data.Common",
    "sl":  "clr-namespace:System.Linq;assembly=System.Linq",
    "njl": "clr-namespace:Newtonsoft.Json.Linq;assembly=Newtonsoft.Json",
    "uix": "clr-namespace:UiPath.UIAutomationNext.Activities;assembly=UiPath.UIAutomationNext.Activities",
}


def parse_arg(spec):
    """'name:Direction:Type' -> (name, direction, type). Type may contain ':'
    for namespaced custom types, e.g. p:OutputData."""
    parts = spec.split(":", 2)
    if len(parts) != 3:
        sys.exit(f"bad --arg '{spec}', expected name:Direction:Type")
    name, direction, typ = parts
    if direction not in DIRECTION:
        sys.exit(f"bad direction '{direction}' in --arg '{spec}'")
    return name, direction, typ


def load_profile(project_json):
    """Derive a portable profile from project.json: root namespace, Core
    assembly, and dependency-driven extra refs."""
    ns = "DefaultNamespace"
    core_assembly = None
    extra_refs = []
    if project_json and os.path.exists(project_json):
        with open(project_json) as f:
            pj = json.load(f)
        ns = pj.get("name", ns)
        core_assembly = f"{ns}.Core"
        for dep in pj.get("dependencies", {}):
            extra_refs.extend(DEPENDENCY_REFS.get(dep, []))
    return ns, core_assembly, extra_refs


def render_members(args):
    if not args:
        return "  <x:Members />"
    lines = ["  <x:Members>"]
    for name, direction, typ in args:
        wrapper = DIRECTION[direction]
        lines.append(
            f'    <x:Property Name="{escape(name)}" '
            f'Type="{wrapper}({escape(typ)})" />'
        )
    lines.append("  </x:Members>")
    return "\n".join(lines)


def render_collection(tag, type_args, items):
    out = [f'    <sco:Collection x:TypeArguments="{type_args}">']
    for it in items:
        out.append(f"      <{tag}>{escape(it)}</{tag}>")
    out.append("    </sco:Collection>")
    return "\n".join(out)


def render_skeleton_body(name):
    """Default body: Log start / Log end — the dominant invokable-workflow idiom."""
    return f"""    <ui:LogMessage DisplayName="Log Message - Workflow Started" sap2010:WorkflowViewState.IdRef="LogMessage_1" Level="Info" Message="[&quot;{escape(name)} workflow started&quot;]" />
    <ui:LogMessage DisplayName="Log Message - Workflow Completed" sap2010:WorkflowViewState.IdRef="LogMessage_2" Level="Info" Message="[&quot;{escape(name)} workflow completed&quot;]" />"""


def generate(name, args, profile, body=None):
    ns, core_assembly, extra_refs = profile
    namespaces = list(BASE_NAMESPACES) + [ns]
    references = list(BASE_REFERENCES) + extra_refs
    if core_assembly:
        references.append(core_assembly)

    p_xmlns = (f'xmlns:p="clr-namespace:{ns};'
               f'assembly={core_assembly}" ' if core_assembly else "")

    members = render_members(args)
    ns_block = render_collection("x:String", "x:String", namespaces)
    ref_block = render_collection("AssemblyReference", "AssemblyReference",
                                  references)
    body = body or render_skeleton_body(name)

    # Auto-declare any KNOWN namespace prefix that the members or body actually
    # use (e.g. sd:DataTable, s:Exception) so the file stays well-formed. Without
    # this, an arg/activity using an undeclared prefix makes Studio reject it.
    extra_xmlns = ""
    used = set(re.findall(r'\b([a-z]{1,4}):[A-Z]', members + body))
    used |= set(re.findall(r'\(([a-z]{1,4}):', members))  # InArgument(sd:DataTable)
    for pfx in sorted(used):
        if pfx in OPTIONAL_XMLNS:
            extra_xmlns += f'xmlns:{pfx}="{OPTIONAL_XMLNS[pfx]}" '

    return f"""<Activity mc:Ignorable="sap sap2010" x:Class="{escape(name)}" xmlns="http://schemas.microsoft.com/netfx/2009/xaml/activities" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" {p_xmlns}{extra_xmlns}xmlns:sap="http://schemas.microsoft.com/netfx/2009/xaml/activities/presentation" xmlns:sap2010="http://schemas.microsoft.com/netfx/2010/xaml/activities/presentation" xmlns:scg="clr-namespace:System.Collections.Generic;assembly=System.Private.CoreLib" xmlns:sco="clr-namespace:System.Collections.ObjectModel;assembly=System.Private.CoreLib" xmlns:ui="http://schemas.uipath.com/workflow/activities" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml">
{members}
  <VisualBasic.Settings>
    <x:Null />
  </VisualBasic.Settings>
  <sap2010:WorkflowViewState.IdRef>{escape(name)}_1</sap2010:WorkflowViewState.IdRef>
  <TextExpression.NamespacesForImplementation>
{ns_block}
  </TextExpression.NamespacesForImplementation>
  <TextExpression.ReferencesForImplementation>
{ref_block}
  </TextExpression.ReferencesForImplementation>
  <Sequence DisplayName="{escape(name)}" sap2010:WorkflowViewState.IdRef="Sequence_1">
    <sap:WorkflowViewStateService.ViewState>
      <scg:Dictionary x:TypeArguments="x:String, x:Object">
        <x:Boolean x:Key="IsExpanded">True</x:Boolean>
      </scg:Dictionary>
    </sap:WorkflowViewStateService.ViewState>
{body}
  </Sequence>
</Activity>
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--project-json")
    ap.add_argument("--arg", action="append", default=[],
                    help="name:Direction:Type (repeatable)")
    ap.add_argument("--body-file", help="file with the inner activity-tree XAML")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    args = [parse_arg(s) for s in a.arg]
    profile = load_profile(a.project_json)
    body = None
    if a.body_file:
        with open(a.body_file) as f:
            body = f.read()
    xaml = generate(a.name, args, profile, body)
    with open(a.out, "w") as f:
        f.write(xaml)
    print(f"wrote {a.out} ({len(xaml)} bytes)")


if __name__ == "__main__":
    main()
