# UiPath expression syntax (VB.NET) inside XAML

UiPath Windows-target projects use **VisualBasic** as the expression language.
Expressions appear in two places, and the bracket/escaping rules differ.

## 1. Activity argument values → wrap in `[ ]`

Inside `<InArgument>`, `<OutArgument>`, `<InOutArgument>`, and on attribute
expressions, the expression body is wrapped in square brackets:

```xml
<InArgument x:TypeArguments="x:String">[in_strOutputNotes]</InArgument>
<InArgument x:TypeArguments="p:OutputData">[New Pgh_…Dispatcher.OutputData]</InArgument>
```

A **string literal** is a VB string *inside* the brackets, so the quotes must be
XML-escaped to `&quot;`:

```xml
Message="[&quot;Workflow started&quot;]"
QueueName="[in_Config(&quot;CPRQueueName&quot;).ToString]"
```

A bare attribute value with NO brackets is a literal, not an expression:

```xml
Level="Info"              <!-- literal enum value -->
NumberOfRetries="3"       <!-- literal -->
WorkflowFileName="Frameworks\AddOutputNotes.xaml"   <!-- literal path -->
```

## 2. XML escaping (always)

| Char | Escape |
|---|---|
| `"` | `&quot;` |
| `&` | `&amp;` |
| `<` | `&lt;` |
| `>` | `&gt;` |
| newline (in annotations) | `&#xA;` |

## 3. Common VB idioms seen in real workflows

```
in_Config("Key").ToString.Trim                 ' read a config dictionary value
Path.GetFileName(in_EFTFileName)               ' System.IO, already imported
String.IsNullOrWhiteSpace(row("Name").ToString)' guard
Not (…)                                         ' boolean negation
in_currentClaim.SelectToken("SVC_loop[0].DTM[0].date") Is Nothing   ' JObject path, Newtonsoft
New Pgh_ApplyPartD_CashPosting_Dispatcher.OutputData                ' construct custom type
row("ColumnName").ToString                      ' DataRow access
```

## 4. Typed arguments — `x:TypeArguments`

The type on `InArgument`/`OutArgument` must match the variable/argument type:

| Value kind | `x:TypeArguments` |
|---|---|
| string | `x:String` |
| boolean | `x:Boolean` |
| integer | `x:Int32` |
| decimal | `x:Decimal` |
| DateTime | `s:DateTime` (requires `s:` prefix) |
| DataTable | `sd:DataTable` |
| custom model | `p:YourType` (requires `p:` prefix + Core assembly ref) |
| dictionary config | `scg:Dictionary(x:String, x:Object)` |

## 5. Gotchas

- VB is **case-insensitive** but match existing casing for readability.
- `Nothing` is VB null; `Is Nothing` / `IsNot Nothing` for null checks (never `=`).
- String concatenation uses `&` (which becomes `&amp;` in XML), or `+`.
- A custom type used in any expression requires BOTH the `p:` namespace declared
  on root AND the project `.Core` assembly in `ReferencesForImplementation` —
  `new_workflow.py` adds both when given `--project-json`.
