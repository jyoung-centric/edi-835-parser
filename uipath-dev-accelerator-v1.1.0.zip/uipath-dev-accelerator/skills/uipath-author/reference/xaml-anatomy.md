# UiPath .xaml anatomy — what's mandatory vs. optional

A UiPath workflow file is a Windows Workflow Foundation XAML document. Studio
will refuse to open a file that is malformed in the **mandatory** parts and will
silently re-layout the **optional** parts. Authoring reliability comes entirely
from getting the mandatory scaffold right (the generator does this) and writing
a valid activity tree (the model does this).

## Top-to-bottom structure

```
<Activity x:Class="WorkflowName" xmlns=… >        ← MANDATORY root + namespace block
  <x:Members> … </x:Members>                       ← arguments (In/Out/InOut)
  <VisualBasic.Settings><x:Null/></VisualBasic.Settings>
  <sap2010:WorkflowViewState.IdRef>…</…>            ← optional (regenerated)
  <TextExpression.NamespacesForImplementation>…</…> ← MANDATORY for expressions to compile
  <TextExpression.ReferencesForImplementation>…</…> ← MANDATORY for types to resolve
  <Sequence|Flowchart …>                            ← MANDATORY single root activity
     <Sequence.Variables> … </Sequence.Variables>   ← local variables (optional)
     <sap:WorkflowViewStateService.ViewState>…</…>  ← optional (regenerated)
     …activity tree…                                ← THE LOGIC
  </Sequence>
</Activity>
```

## Mandatory (get wrong → Studio won't open it)

| Part | Rule |
|---|---|
| Root `<Activity x:Class="…">` | Class name should match the file name (no extension). |
| Namespace declarations | Every prefix used anywhere (`ui:`, `p:`, `sd:`, `s:`, `scg:`, `sco:`…) MUST be declared on the root `<Activity>`. Undeclared prefix = hard failure. |
| `NamespacesForImplementation` | The list of imported namespaces VB expressions resolve against. The base list is universal; add the project root namespace so custom types resolve unqualified. |
| `ReferencesForImplementation` | Assembly references. Universal base + one per UiPath package dependency + the project `.Core` assembly for custom types. |
| Single root activity | Exactly one child activity under `<Activity>` (normally `Sequence` or `Flowchart`). |
| Argument types in `x:Members` | `Type="InArgument(x:String)"`, `OutArgument(...)`, `InOutArgument(...)`. Custom types use the `p:` prefix. |

## Optional (Studio regenerates — safe to omit or stub)

| Part | Notes |
|---|---|
| `sap:VirtualizedContainerService.HintSize` | Designer node size. Omit entirely. |
| `sap2010:WorkflowViewState.IdRef` | Designer node id. Omit, or use a stub like `Sequence_1`. |
| `WorkflowViewStateService.ViewState` dictionaries | `IsExpanded`/`IsPinned` flags. Omit; default collapsed/expanded is fine. |
| `sap2010:Annotation.AnnotationText` | Developer annotations. Keep if you have something useful to say. |

## The 85/15 split that makes generation reliable

~85% of a file (root element, the two `TextExpression` lists, the members block)
is **deterministic scaffold** produced mechanically by `new_workflow.py`. The
remaining ~15% — the `<x:Members>` argument list and the activity tree inside the
root `Sequence` — is the only part that requires authoring judgment. Author the
body from vetted snippets in `fragments.xaml`, then run `validate_xaml.py`.

## Prefix cheat-sheet (declare on root as needed)

| Prefix | Namespace | When |
|---|---|---|
| `ui` | `http://schemas.uipath.com/workflow/activities` | any UiPath activity |
| `x` | `http://schemas.microsoft.com/winfx/2006/xaml` | always |
| (default) | `…/2009/xaml/activities` | base WF activities (Sequence, Assign, If…) |
| `p` | `clr-namespace:{Project};assembly={Project}.Core` | custom data-model types |
| `s` | `clr-namespace:System;assembly=System.Private.CoreLib` | `s:Exception` in catches |
| `sd` | `clr-namespace:System.Data;assembly=System.Data.Common` | `sd:DataRow` in ForEachRow |
| `scg` | `System.Collections.Generic` | `scg:List`, `scg:Dictionary` |
| `sco` | `System.Collections.ObjectModel` | the TextExpression collections |
