#!/usr/bin/env python3
"""
read_workflow.py — turn a verbose UiPath .xaml into a compact, readable outline.

A UiPath workflow file is mostly designer view-state noise (HintSize, IdRef,
ViewState dictionaries, the two huge TextExpression lists). The actual logic is a
thin signal. This tool strips the noise and prints the SIGNAL: arguments,
variables, the nested activity tree (by DisplayName + type), invoked workflows,
key expressions, and selectors — so Claude (and humans) can understand a workflow
at a fraction of the tokens of the raw file.

Usage:
    read_workflow.py path/to/Workflow.xaml           # outline
    read_workflow.py path/to/Workflow.xaml --exprs   # also dump expressions
    read_workflow.py Dir/ --summary                  # one-line summary per file
"""
import argparse, glob, os, re, sys
import xml.etree.ElementTree as ET

# activities we render with an extra bit of context (their key attribute)
KEY_ATTR = {
    "LogMessage": "Message", "InvokeWorkflowFile": "WorkflowFileName",
    "AddQueueItem": "QueueType", "GetQueueItems": "QueueName",
    "AddTransactionItem": "QueueType", "SetTransactionStatus": "Status",
    "If": "Condition", "IfElseIfV2": "Condition", "FlowDecision": "Condition",
    "RetryScope": "NumberOfRetries", "Assign": None, "ForEach": "Values",
    "ForEachRow": "DataTable",
}
NOISE_TAGS = {  # containers/structure we don't want as tree nodes
    "Members", "Property", "Variables", "Variable", "Settings",
    "NamespacesForImplementation", "ReferencesForImplementation",
    "WorkflowViewState.IdRef", "ViewState", "Collection", "Dictionary",
    "Boolean", "String", "AssemblyReference", "Null",
    # value wrappers — the Assign/argument leaves are noise in a tree view
    "InArgument", "OutArgument", "InOutArgument", "Literal", "VisualBasicValue",
    "VisualBasicReference", "DelegateInArgument", "ActivityAction",
    "ActivityFunc", "Argument",
}

def localname(tag):
    return tag.rsplit("}", 1)[-1].rsplit(":", 1)[-1]

def strip_ns(txt):
    # ElementTree keeps namespaces as {uri}local; we only ever use localname()
    return txt

def get_disp(el):
    for k, v in el.attrib.items():
        if localname(k) == "DisplayName":
            return v
    return None

def brief_expr(s, n=70):
    if s is None: return ""
    s = s.strip()
    return (s[:n] + "…") if len(s) > n else s

def render(el, depth, out, opts):
    name = localname(el.tag)
    if name in NOISE_TAGS or name.endswith(".Variables") or "." in name and \
       localname(name.split(".")[-1]) in ("ViewState", "IdRef"):
        # still recurse into structural property-element wrappers (e.g. If.Then)
        if "." in name:
            for c in el:
                render(c, depth, out, opts)
        return
    disp = get_disp(el)
    # skip pure property-element wrappers but keep their children at same depth
    if "." in name and disp is None:
        for c in el:
            render(c, depth, out, opts)
        return
    label = disp or name
    extra = ""
    ka = KEY_ATTR.get(name, "unset")
    if ka and ka != "unset":
        for k, v in el.attrib.items():
            if localname(k) == ka:
                extra = f"  → {ka}={brief_expr(v)}"
                break
    # selectors
    for k, v in el.attrib.items():
        if localname(k) in ("Selector", "FullSelector") and v.strip():
            extra += f"  [selector]"
            break
    line = "  " * depth + f"• {label}" + (f"  «{name}»" if disp else "") + extra
    out.append(line)
    for c in el:
        render(c, depth + 1, out, opts)

def parse_args_block(root):
    args = []
    for m in root.iter():
        if localname(m.tag) == "Property":
            nm = m.attrib.get("Name") or m.attrib.get(
                "{http://schemas.microsoft.com/winfx/2006/xaml}Name")
            typ = None
            for k, v in m.attrib.items():
                if localname(k) == "Type":
                    typ = v
            if nm:
                args.append((nm, typ))
    return args

def outline(path, opts):
    txt = open(path, encoding="utf-8").read()
    try:
        root = ET.fromstring(txt)
    except ET.ParseError as e:
        return [f"!! parse error: {e}"]
    cls = None
    for k, v in root.attrib.items():
        if localname(k) == "Class":
            cls = v
    out = [f"WORKFLOW: {cls or os.path.basename(path)}"]
    args = parse_args_block(root)
    if args:
        out.append("ARGUMENTS:")
        for nm, typ in args:
            out.append(f"  - {nm}: {typ}")
    # invoked workflows
    invokes = sorted(set(re.findall(r'WorkflowFileName="([^"]+)"', txt)))
    if invokes:
        out.append("INVOKES: " + ", ".join(os.path.basename(i.replace("\\", "/")) for i in invokes))
    # config keys
    cfg = sorted(set(re.findall(r'(?:in_)?Config\(&quot;([^&]+)&quot;\)', txt)))
    if cfg:
        out.append("CONFIG KEYS: " + ", ".join(cfg[:20]) + ("…" if len(cfg) > 20 else ""))
    out.append("TREE:")
    # find the root activity body (first child that's a real activity)
    for c in root:
        render(c, 1, out, opts)
    if opts.exprs:
        exprs = re.findall(r'\[([^\]]{3,})\]', txt)
        seen, uniq = set(), []
        for e in exprs:
            if e not in seen and not e.startswith("x:") and "TypeArguments" not in e:
                seen.add(e); uniq.append(e)
        out.append("EXPRESSIONS:")
        for e in uniq[:60]:
            out.append("  " + brief_expr(e, 90))
    return out

def summary(path):
    txt = open(path, encoding="utf-8").read()
    cls = (re.search(r'x:Class="([^"]+)"', txt) or [None, os.path.basename(path)])[1]
    acts = len(re.findall(r'DisplayName="', txt))
    inv = len(set(re.findall(r'WorkflowFileName="([^"]+)"', txt)))
    sel = len(re.findall(r'(?:Selector|FullSelector)="[^"]+', txt))
    return f"{cls:40s} activities≈{acts:<4} invokes={inv:<3} selectors={sel}"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--exprs", action="store_true", help="also list expressions")
    ap.add_argument("--summary", action="store_true", help="one-line per file")
    a = ap.parse_args()
    if os.path.isdir(a.path):
        files = sorted(glob.glob(os.path.join(a.path, "**/*.xaml"), recursive=True))
        for f in files:
            if a.summary:
                print(summary(f))
            else:
                print("\n".join(outline(f, a)))
                print()
    else:
        if a.summary:
            print(summary(a.path))
        else:
            print("\n".join(outline(a.path, a)))

if __name__ == "__main__":
    main()
