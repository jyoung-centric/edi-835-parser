---
name: uipath-reader
description: >
  Read and understand existing UiPath workflows (.xaml) cheaply. Use when you need
  to comprehend, navigate, summarize, or answer questions about UiPath workflows —
  before editing them, reviewing them, or planning changes. Strips designer
  view-state noise and prints a compact outline (arguments, activity tree, invoked
  workflows, config keys, selectors, expressions) at a fraction of the tokens of
  the raw XAML.

---

# uipath-reader

A raw UiPath `.xaml` is mostly noise — designer coordinates (`HintSize`), node ids
(`IdRef`), `ViewState` dictionaries, and the two large `TextExpression` lists. A
497 KB `Main.xaml` might contain only a few KB of actual logic. Reading the raw
file wastes context and buries the signal. This skill extracts the signal.

## When to use

- **Before editing** a workflow — get its shape and argument contract fast.
- **Before planning** (`uipath-plan`) — understand what an existing workflow does.
- **Reviewing / auditing** — scan a whole `Frameworks/` or `DataFiles/` folder.
- Answering "what does workflow X do / what does it call / what selectors / config
  does it use."

Prefer this over reading raw `.xaml` with the file tools. Only fall back to raw
XAML when you need exact view-state or an attribute the outline omits.

## Usage

```bash
# Full outline of one workflow: args, tree, invokes, config keys
python3 scripts/read_workflow.py path/to/Workflow.xaml

# Also dump the distinct VB expressions used
python3 scripts/read_workflow.py path/to/Workflow.xaml --exprs

# One-line summary per file across a folder (great for orientation)
python3 scripts/read_workflow.py path/to/Frameworks/ --summary
```

## Output

- `WORKFLOW:` the `x:Class` name.
- `ARGUMENTS:` each argument with direction+type (the invocation contract).
- `INVOKES:` the `.xaml` files this workflow calls (the dependency edges).
- `CONFIG KEYS:` `in_Config(...)` keys it reads.
- `TREE:` the activity tree by DisplayName + activity type, indented by nesting,
  with key attributes inline (LogMessage message, If condition, queue names,
  `[selector]` markers).
- `EXPRESSIONS:` (with `--exprs`) the distinct VB expressions.

`--summary` prints `class · activity-count · invoke-count · selector-count` per
file — the fastest way to map an unfamiliar project.

## Notes

- Pure static parse (ElementTree + regex); no UiPath install needed.
- Feeds the rest of the accelerator: `uipath-plan` uses the same signals to ground
  a story; `uipath-selectors` drills into the selectors this tool merely flags.
- On a malformed file it prints `!! parse error` rather than crashing.
