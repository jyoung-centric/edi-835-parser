<#
.SYNOPSIS
    Install the UiPath Dev Accelerator skills for Claude Code on Windows.

.DESCRIPTION
    Copies each skill under skills/ into a Claude Code skills directory so Claude
    discovers them. Skills are installed as sibling directories (required — the
    uipath-plan → uipath-orchestrator-api cross-wire resolves the sibling by
    relative path).

.PARAMETER Scope
    User    : %USERPROFILE%\.claude\skills   (default — available in ALL projects)
    Project : <ProjectPath>\.claude\skills   (scoped to one project)

.PARAMETER ProjectPath
    Target project directory when -Scope Project. Defaults to the current dir.

.PARAMETER Force
    Overwrite an existing installed copy of a skill.

.EXAMPLE
    .\install.ps1
    .\install.ps1 -Scope Project -ProjectPath C:\src\MyUiPathProject
    .\install.ps1 -Force
#>
[CmdletBinding()]
param(
    [ValidateSet('User', 'Project')]
    [string]$Scope = 'User',
    [string]$ProjectPath = (Get-Location).Path,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$repoRoot   = Split-Path -Parent $MyInvocation.MyCommand.Path
$skillsSrc  = Join-Path $repoRoot 'skills'

if (-not (Test-Path $skillsSrc)) {
    throw "skills/ not found next to install.ps1 (looked in $skillsSrc)"
}

# Resolve destination
if ($Scope -eq 'User') {
    $dest = Join-Path $env:USERPROFILE '.claude\skills'
} else {
    if (-not (Test-Path $ProjectPath)) { throw "ProjectPath not found: $ProjectPath" }
    $dest = Join-Path $ProjectPath '.claude\skills'
}
New-Item -ItemType Directory -Force -Path $dest | Out-Null

Write-Host "UiPath Dev Accelerator — installing skills"
Write-Host "  scope : $Scope"
Write-Host "  dest  : $dest"
Write-Host ""

# Optional: note Python availability (scripts need Python 3; not required to install)
$py = Get-Command python -ErrorAction SilentlyContinue
if (-not $py) { $py = Get-Command py -ErrorAction SilentlyContinue }
if ($py) {
    Write-Host "  python: $($py.Source)"
} else {
    Write-Warning "Python 3 not found on PATH. The skills' scripts require Python 3 to run.`n           Install from https://www.python.org/downloads/ (check 'Add to PATH')."
}
Write-Host ""

$installed = 0
Get-ChildItem -Path $skillsSrc -Directory | ForEach-Object {
    $name   = $_.Name
    $target = Join-Path $dest $name
    if ((Test-Path $target) -and -not $Force) {
        Write-Warning "skip  $name  (exists — use -Force to overwrite)"
        return
    }
    if (Test-Path $target) { Remove-Item -Recurse -Force $target }
    # copy, excluding caches
    Copy-Item -Recurse -Force $_.FullName $target
    Get-ChildItem -Path $target -Recurse -Directory -Filter '__pycache__' |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "ok    $name"
    $installed++
}

Write-Host ""
Write-Host "Installed $installed skill(s) to $dest"
Write-Host "Restart Claude Code (or reload) so it re-scans the skills directory."
